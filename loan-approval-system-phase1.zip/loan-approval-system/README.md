# Agentic AI Intelligent Loan Approval System — Phase 1

This phase provides the project foundation: configuration, Pydantic models, a local SQLite database, a repository, sample records, and initial tests. Agent logic and LangGraph orchestration will be added in later phases.

## Requirements

- Windows 10/11
- Python 3.11 recommended
- VS Code
- Anthropic API key (not needed to run Phase 1 tests)

## Windows CMD setup

```bat
cd loan-approval-system
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
copy .env.example .env
```

Open `.env` and set `ANTHROPIC_API_KEY` to your own key. Do not share `.env` or commit it to source control.

## Initialize the database and sample records

```bat
python -m database.seed_data
```

## Run Phase 1 tests

```bat
pytest -q
```

## Open the project in VS Code

```bat
code .
```

## Notes

- The SQLite database is created at `data/loan_approval.db`.
- The seed data is fictional demonstration data.
- The models are for a learning prototype, not a production lending decision system.
- Actual credit policy, risk thresholds, compliance requirements, and model choices must be validated with the lender.
