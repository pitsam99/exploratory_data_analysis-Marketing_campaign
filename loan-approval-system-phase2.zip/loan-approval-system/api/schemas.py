# API schemas will be expanded in Phase 5.
