# Agentic AI Loan Approval System — Phase 2

Phase 2 adds the Applicant Profile Agent, Financial Risk Analysis Agent, deterministic affordability calculations, demonstration policy rules, and unit tests.

## Setup (Windows CMD)

```bat
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
copy .env.example .env
```

Edit `.env` and set `ANTHROPIC_API_KEY` to your key. Do not commit or share `.env`.

## Run tests

```bat
pytest -q
```

## Agent examples

Run a quick interactive check from the project root:

```bat
python -c "from agents.applicant_profile_agent import ApplicantProfileAgent; from agents.financial_risk_agent import FinancialRiskAgent; from models.loan_application import LoanApplicationCreate, EmploymentType; a=LoanApplicationCreate(applicant_id='DEMO-1001', age=35, monthly_income=100000, employment_type=EmploymentType.SALARIED, credit_score=760, loan_amount=1200000, tenure_months=60, existing_monthly_liabilities=15000, location='Kolkata'); print('PROFILE:', ApplicantProfileAgent().run(a).model_dump_json(indent=2)); print('RISK:', FinancialRiskAgent().run(a, annual_interest_rate_percent=12).model_dump_json(indent=2))"
```

## Important limitations

- The agents are deterministic Phase 2 implementations; Claude is not called yet.
- Profile scores and risk bands are demonstration heuristics, not validated underwriting models.
- The original case study does not supply an interest rate. If no rate is passed, proposed EMI and projected DTI remain unknown, and manual review is recommended.
- `services/business_rules_service.py` contains example policy values only. Do not use them for real credit decisions without lender approval, validation, fairness review, and legal/compliance review.
- MCP integration and LangGraph orchestration are future phases.
