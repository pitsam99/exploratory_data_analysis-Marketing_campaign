from database.connection import init_db
from database.repository import create_application, list_applications
from models.loan_application import LoanApplicationCreate, EmploymentType


SAMPLE_APPLICATIONS = [
    {
        "applicant_id": "DEMO-1001",
        "age": 35,
        "monthly_income": 100000,
        "employment_type": EmploymentType.SALARIED,
        "credit_score": 760,
        "loan_amount": 1200000,
        "tenure_months": 60,
        "existing_monthly_liabilities": 15000,
        "location": "Kolkata",
    },
    {
        "applicant_id": "DEMO-1002",
        "age": 42,
        "monthly_income": 65000,
        "employment_type": EmploymentType.SELF_EMPLOYED,
        "credit_score": 690,
        "loan_amount": 900000,
        "tenure_months": 48,
        "existing_monthly_liabilities": 18000,
        "location": "Pune",
    },
    {
        "applicant_id": "DEMO-1003",
        "age": 29,
        "monthly_income": 45000,
        "employment_type": EmploymentType.CONTRACT,
        "credit_score": 620,
        "loan_amount": 1500000,
        "tenure_months": 60,
        "existing_monthly_liabilities": 20000,
        "location": "Jaipur",
    },
]


def main() -> None:
    init_db()
    existing_ids = {record.applicant_id for record in list_applications(limit=1000)}
    inserted = 0
    for item in SAMPLE_APPLICATIONS:
        if item["applicant_id"] not in existing_ids:
            create_application(LoanApplicationCreate(**item))
            inserted += 1
    print(f"Database initialized. Inserted {inserted} sample application(s).")
    print(f"Total applications in database: {len(list_applications(limit=1000))}")


if __name__ == "__main__":
    main()
