from datetime import datetime
from sqlalchemy import DateTime, Float, Integer, String, select
from sqlalchemy.orm import Mapped, Session, mapped_column
from database.connection import Base, SessionLocal
from models.loan_application import LoanApplicationCreate


class LoanApplicationRecord(Base):
    __tablename__ = "loan_applications"

    application_id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    applicant_id: Mapped[str] = mapped_column(String(64), index=True)
    age: Mapped[int] = mapped_column(Integer)
    monthly_income: Mapped[float] = mapped_column(Float)
    employment_type: Mapped[str] = mapped_column(String(32))
    credit_score: Mapped[int] = mapped_column(Integer)
    loan_amount: Mapped[float] = mapped_column(Float)
    tenure_months: Mapped[int] = mapped_column(Integer)
    existing_monthly_liabilities: Mapped[float] = mapped_column(Float)
    location: Mapped[str] = mapped_column(String(120))
    application_timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    status: Mapped[str] = mapped_column(String(40), default="Submitted")


def create_application(data: LoanApplicationCreate) -> LoanApplicationRecord:
    with SessionLocal() as session:
        record = LoanApplicationRecord(
            applicant_id=data.applicant_id,
            age=data.age,
            monthly_income=data.monthly_income,
            employment_type=data.employment_type.value,
            credit_score=data.credit_score,
            loan_amount=data.loan_amount,
            tenure_months=data.tenure_months,
            existing_monthly_liabilities=data.existing_monthly_liabilities,
            location=data.location,
            application_timestamp=data.application_timestamp.replace(tzinfo=None),
            status="Submitted",
        )
        session.add(record)
        session.commit()
        session.refresh(record)
        return record


def get_application(application_id: int) -> LoanApplicationRecord | None:
    with SessionLocal() as session:
        return session.scalar(
            select(LoanApplicationRecord).where(
                LoanApplicationRecord.application_id == application_id
            )
        )


def list_applications(limit: int = 100) -> list[LoanApplicationRecord]:
    with SessionLocal() as session:
        return list(
            session.scalars(
                select(LoanApplicationRecord)
                .order_by(LoanApplicationRecord.application_id.desc())
                .limit(limit)
            ).all()
        )
