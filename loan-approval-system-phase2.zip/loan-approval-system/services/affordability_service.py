from dataclasses import dataclass


@dataclass(frozen=True)
class AffordabilityResult:
    existing_dti_percent: float
    proposed_emi: float | None
    projected_dti_percent: float | None


def calculate_emi(principal: float, annual_interest_rate_percent: float, months: int) -> float:
    """Calculate fixed-rate monthly EMI. Requires a positive principal and term."""
    if principal <= 0:
        raise ValueError("principal must be greater than zero")
    if months <= 0:
        raise ValueError("months must be greater than zero")
    if annual_interest_rate_percent < 0:
        raise ValueError("interest rate cannot be negative")

    monthly_rate = annual_interest_rate_percent / 100 / 12
    if monthly_rate == 0:
        return principal / months
    factor = (1 + monthly_rate) ** months
    return principal * monthly_rate * factor / (factor - 1)


def assess_affordability(
    monthly_income: float,
    existing_monthly_liabilities: float,
    loan_amount: float,
    tenure_months: int,
    annual_interest_rate_percent: float | None = None,
) -> AffordabilityResult:
    if monthly_income <= 0:
        raise ValueError("monthly_income must be greater than zero")
    if existing_monthly_liabilities < 0:
        raise ValueError("existing_monthly_liabilities cannot be negative")

    existing_dti = existing_monthly_liabilities / monthly_income * 100
    if annual_interest_rate_percent is None:
        return AffordabilityResult(existing_dti, None, None)

    emi = calculate_emi(loan_amount, annual_interest_rate_percent, tenure_months)
    projected_dti = (existing_monthly_liabilities + emi) / monthly_income * 100
    return AffordabilityResult(existing_dti, emi, projected_dti)
