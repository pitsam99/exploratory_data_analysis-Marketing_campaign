from models.loan_application import LoanApplicationCreate


# Demonstration-only policy values. Replace with lender-approved, versioned policy.
DEMO_POLICY = {
    "minimum_credit_score": 650,
    "maximum_projected_dti_percent": 40.0,
    "maximum_existing_dti_percent_for_auto_assessment": 35.0,
    "policy_version": "demo-1.0",
}


def profile_completeness_flags(application: LoanApplicationCreate) -> list[str]:
    flags: list[str] = []
    required_values = {
        "applicant_id": application.applicant_id,
        "age": application.age,
        "monthly_income": application.monthly_income,
        "employment_type": application.employment_type,
        "credit_score": application.credit_score,
        "loan_amount": application.loan_amount,
        "tenure_months": application.tenure_months,
        "location": application.location,
    }
    for field, value in required_values.items():
        if value is None or value == "":
            flags.append(f"Missing required field: {field}")
    return flags


def credit_score_risk_level(credit_score: int) -> str:
    if credit_score >= 750:
        return "Low"
    if credit_score >= 680:
        return "Moderate"
    if credit_score >= DEMO_POLICY["minimum_credit_score"]:
        return "Elevated"
    return "High"
