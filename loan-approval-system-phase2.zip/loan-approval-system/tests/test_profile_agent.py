from agents.applicant_profile_agent import ApplicantProfileAgent
from models.loan_application import LoanApplicationCreate, EmploymentType


def make_application():
    return LoanApplicationCreate(
        applicant_id="TEST-2001",
        age=35,
        monthly_income=100000,
        employment_type=EmploymentType.SALARIED,
        credit_score=760,
        loan_amount=1200000,
        tenure_months=60,
        existing_monthly_liabilities=15000,
        location="Kolkata",
    )


def test_profile_agent_returns_structured_result():
    result = ApplicantProfileAgent().run(make_application())
    assert result.income_stability_score == 85.0
    assert result.employment_risk == "Lower indicator"
    assert result.application_completeness_flags == []
    assert result.warnings
