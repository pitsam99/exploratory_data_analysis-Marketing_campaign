import pytest
from pydantic import ValidationError
from models.loan_application import LoanApplicationCreate, EmploymentType


def valid_payload():
    return {
        "applicant_id": "TEST-1001",
        "age": 35,
        "monthly_income": 100000,
        "employment_type": EmploymentType.SALARIED,
        "credit_score": 760,
        "loan_amount": 1200000,
        "tenure_months": 60,
        "existing_monthly_liabilities": 15000,
        "location": "Kolkata",
    }


def test_valid_application_model():
    application = LoanApplicationCreate(**valid_payload())
    assert application.applicant_id == "TEST-1001"
    assert application.credit_score == 760


def test_rejects_invalid_credit_score():
    payload = valid_payload()
    payload["credit_score"] = 1000
    with pytest.raises(ValidationError):
        LoanApplicationCreate(**payload)


def test_rejects_underage_applicant():
    payload = valid_payload()
    payload["age"] = 17
    with pytest.raises(ValidationError):
        LoanApplicationCreate(**payload)
