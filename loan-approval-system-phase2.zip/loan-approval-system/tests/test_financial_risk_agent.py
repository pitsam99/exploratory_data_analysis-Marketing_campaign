import pytest
from agents.financial_risk_agent import FinancialRiskAgent
from models.loan_application import LoanApplicationCreate, EmploymentType
from services.affordability_service import calculate_emi


def make_application():
    return LoanApplicationCreate(
        applicant_id="TEST-3001",
        age=35,
        monthly_income=100000,
        employment_type=EmploymentType.SALARIED,
        credit_score=760,
        loan_amount=1200000,
        tenure_months=60,
        existing_monthly_liabilities=15000,
        location="Kolkata",
    )


def test_existing_dti_is_calculated():
    result = FinancialRiskAgent().run(make_application())
    assert result.existing_debt_to_income_ratio == 15.0
    assert result.proposed_emi is None
    assert result.requires_manual_review is True


def test_emi_with_zero_interest():
    assert calculate_emi(120000, 0, 12) == pytest.approx(10000)


def test_emi_rejects_negative_interest():
    with pytest.raises(ValueError):
        calculate_emi(120000, -1, 12)


def test_projected_dti_when_rate_is_supplied():
    result = FinancialRiskAgent().run(make_application(), annual_interest_rate_percent=12)
    assert result.proposed_emi is not None
    assert result.projected_debt_to_income_ratio is not None
    assert result.projected_debt_to_income_ratio > result.existing_debt_to_income_ratio
