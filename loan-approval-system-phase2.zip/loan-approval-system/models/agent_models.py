from pydantic import BaseModel, Field


class ApplicantProfileResult(BaseModel):
    income_stability_score: float | None = Field(default=None, ge=0, le=100)
    employment_risk: str | None = None
    credit_history_summary: str | None = None
    application_completeness_flags: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class FinancialRiskResult(BaseModel):
    existing_debt_to_income_ratio: float | None = Field(default=None, ge=0)
    proposed_emi: float | None = Field(default=None, ge=0)
    projected_debt_to_income_ratio: float | None = Field(default=None, ge=0)
    credit_score_risk_level: str | None = None
    loan_amount_risk: str | None = None
    anomalies: list[str] = Field(default_factory=list)
    reasoning: list[str] = Field(default_factory=list)
    requires_manual_review: bool = False
