from datetime import datetime, timezone
from enum import Enum
from pydantic import BaseModel, ConfigDict, Field


class EmploymentType(str, Enum):
    SALARIED = "Salaried"
    SELF_EMPLOYED = "Self-employed"
    CONTRACT = "Contract"
    OTHER = "Other"


class LoanApplicationCreate(BaseModel):
    applicant_id: str = Field(min_length=1, max_length=64)
    age: int = Field(ge=18, le=100)
    monthly_income: float = Field(gt=0)
    employment_type: EmploymentType
    credit_score: int = Field(ge=300, le=900)
    loan_amount: float = Field(gt=0)
    tenure_months: int = Field(ge=1, le=480)
    existing_monthly_liabilities: float = Field(ge=0)
    location: str = Field(min_length=1, max_length=120)
    application_timestamp: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc)
    )


class LoanApplication(LoanApplicationCreate):
    model_config = ConfigDict(from_attributes=True)

    application_id: int
    status: str = "Submitted"


class DecisionClassification(str, Enum):
    APPROVED = "Approved"
    REJECTED = "Rejected"
    MANUAL_REVIEW = "Requires Manual Review"


class AgentResult(BaseModel):
    agent_name: str
    status: str = "completed"
    findings: dict = Field(default_factory=dict)
    warnings: list[str] = Field(default_factory=list)


class LoanDecision(BaseModel):
    classification: DecisionClassification
    risk_score: float | None = Field(default=None, ge=0, le=100)
    confidence_level: str | None = None
    key_decision_factors: list[str] = Field(default_factory=list)
    explanation: str
