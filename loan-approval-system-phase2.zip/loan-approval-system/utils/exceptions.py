# Application-specific exceptions will be added as needed.
