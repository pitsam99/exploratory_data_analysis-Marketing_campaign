from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "Agentic AI Loan Approval System"
    app_env: str = "development"
    log_level: str = "INFO"
    anthropic_api_key: str | None = None
    anthropic_model: str = "claude-sonnet-4-6"
    database_url: str = "sqlite:///./data/loan_approval.db"

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )


@lru_cache
def get_settings() -> Settings:
    return Settings()
