from models.loan_application import LoanApplicationCreate
from models.agent_models import ApplicantProfileResult
from services.business_rules_service import profile_completeness_flags, credit_score_risk_level


class ApplicantProfileAgent:
    """Deterministic Phase 2 profile assessment.

    In a later phase this agent will use ApplicantDB MCP tools to retrieve
    applicant records and verified credit-history information.
    """

    def run(self, application: LoanApplicationCreate) -> ApplicantProfileResult:
        flags = profile_completeness_flags(application)

        # This is a transparent demo heuristic, not a validated credit model.
        employment_scores = {
            "Salaried": 85.0,
            "Self-employed": 70.0,
            "Contract": 60.0,
            "Other": 55.0,
        }
        score = employment_scores.get(application.employment_type.value, 50.0)

        warnings = [
            "Income stability is a demonstration heuristic, not a verified employment-history assessment.",
            "Credit-history summary is limited to the supplied credit score; no bureau report was retrieved.",
        ]
        return ApplicantProfileResult(
            income_stability_score=score,
            employment_risk={
                "Salaried": "Lower indicator",
                "Self-employed": "Moderate indicator",
                "Contract": "Higher indicator",
                "Other": "Unclassified",
            }.get(application.employment_type.value, "Unclassified"),
            credit_history_summary=(
                f"Supplied credit score: {application.credit_score}; "
                f"rule-based risk band: {credit_score_risk_level(application.credit_score)}. "
                "No credit bureau history was retrieved."
            ),
            application_completeness_flags=flags,
            warnings=warnings,
        )
