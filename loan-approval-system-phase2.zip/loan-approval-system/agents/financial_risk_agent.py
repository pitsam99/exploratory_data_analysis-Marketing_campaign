from models.loan_application import LoanApplicationCreate
from models.agent_models import FinancialRiskResult
from services.affordability_service import assess_affordability
from services.business_rules_service import DEMO_POLICY, credit_score_risk_level


class FinancialRiskAgent:
    """Phase 2 deterministic financial assessment.

    The interest rate is not part of the case-study input. Without an explicit
    rate, this agent reports existing DTI but does not invent a proposed EMI.
    """

    def run(
        self,
        application: LoanApplicationCreate,
        annual_interest_rate_percent: float | None = None,
    ) -> FinancialRiskResult:
        affordability = assess_affordability(
            monthly_income=application.monthly_income,
            existing_monthly_liabilities=application.existing_monthly_liabilities,
            loan_amount=application.loan_amount,
            tenure_months=application.tenure_months,
            annual_interest_rate_percent=annual_interest_rate_percent,
        )

        anomalies: list[str] = []
        reasoning: list[str] = [
            f"Existing monthly liabilities are {affordability.existing_dti_percent:.2f}% of stated monthly income."
        ]

        if application.existing_monthly_liabilities > application.monthly_income:
            anomalies.append("Existing monthly liabilities exceed stated monthly income.")
        if application.loan_amount > application.monthly_income * 60:
            anomalies.append("Requested principal exceeds 60 times stated monthly income; verify policy and affordability.")
        if affordability.projected_dti_percent is None:
            reasoning.append("Proposed EMI cannot be calculated until an interest rate is provided.")
        else:
            reasoning.append(
                f"Projected debt-to-income ratio including proposed EMI is {affordability.projected_dti_percent:.2f}%."
            )

        score_band = credit_score_risk_level(application.credit_score)
        if score_band == "High":
            reasoning.append("Credit score falls below the demonstration policy's minimum score.")
        if affordability.projected_dti_percent is not None and (
            affordability.projected_dti_percent > DEMO_POLICY["maximum_projected_dti_percent"]
        ):
            reasoning.append("Projected DTI exceeds the demonstration policy threshold.")

        requires_review = bool(anomalies) or affordability.proposed_emi is None
        return FinancialRiskResult(
            existing_debt_to_income_ratio=round(affordability.existing_dti_percent, 2),
            proposed_emi=(
                round(affordability.proposed_emi, 2)
                if affordability.proposed_emi is not None
                else None
            ),
            projected_debt_to_income_ratio=(
                round(affordability.projected_dti_percent, 2)
                if affordability.projected_dti_percent is not None
                else None
            ),
            credit_score_risk_level=score_band,
            loan_amount_risk=(
                "Requires affordability review"
                if affordability.projected_dti_percent is None
                or affordability.projected_dti_percent > DEMO_POLICY["maximum_projected_dti_percent"]
                else "Within demonstration DTI threshold"
            ),
            anomalies=anomalies,
            reasoning=reasoning,
            requires_manual_review=requires_review,
        )
