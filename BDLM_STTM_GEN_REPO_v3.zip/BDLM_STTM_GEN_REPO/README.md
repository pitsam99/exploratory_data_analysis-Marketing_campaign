# BDLM STTM Generator

Generates **Source-to-Target Mapping (STTM)** documentation from Informatica PowerCenter XML exports. Outputs a professional multi-worksheet XLSX file.

---

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Install package (editable)
pip install -e .

# List mappings in an XML
python -m bldmsttmgen list --xml input/samples/your_mapping.XML

# Validate XML
python -m bldmsttmgen validate --xml input/samples/your_mapping.XML

# Generate STTM for single mapping
python -m bldmsttmgen generate \
  --xml input/samples/your_mapping.XML \
  --mapping your_mapping_name \
  --xlsx-only

# Generate with mapplets
python -m bldmsttmgen generate \
  --xml input/samples/your_mapping.XML \
  --mapping your_mapping_name \
  --mapplet-dir input/mapplets/ \
  --xlsx-only

# Batch generate all XMLs
python -m bldmsttmgen batch \
  --input input/samples/ \
  --pattern *.XML \
  --workers 4 \
  --xlsx-only
```

---

## Folder Structure

```
BDLM_STTM_GEN_REPO/
├── .github/
│   ├── agents/
│   │   └── bldm-sttm.agent.md          # GitHub Copilot Agent
│   └── prompts/
│       ├── generateInformaticaBLDMSTTM.prompt.md
│       └── generateInformaticaSDR.prompt.md
├── src/
│   └── bldmsttmgen/
│       ├── __init__.py
│       ├── __main__.py                  # CLI entry point
│       ├── parser.py                    # XML parser
│       ├── generator.py                 # Core generation logic
│       ├── batch.py                     # Batch processing
│       └── excel_writer.py              # XLSX output
├── input/
│   ├── samples/                         # Put your XML files here
│   └── mapplets/                        # Put mapplet XMLs here
├── output/
│   └── bldmsttm/                        # Generated STTM files appear here
├── tests/
│   └── test_bldmsttmgen.py
├── docs/
│   └── bldm-architecture.md
├── requirements.txt
└── setup.py
```

---

## Output: STTM_\<TARGET_TABLE\>.xlsx

| Sheet | Contents |
|---|---|
| Mapping Overview | Metadata, SQL, data flow, business rules |
| STTM Mapping Table | Field-level source→target with full lineage |
| SQL Query | All Source Qualifier SQL with Rule IDs |
| Joins | All joins with type, keys, cardinality |
| Rules | Business rules R001, R002... |
| Field Lineage | Full trace: SQ→expression→lookup→target |
| Mapplet Dependencies | Resolved/unresolved mapplet details |

---

## Mapplet Handling

```bash
# Option 1: Single mapplet XML
python -m bldmsttmgen generate \
  --xml input/samples/m_mapping.XML \
  --mapping m_mapping \
  --mapplet-xml input/mapplets/mplt_one.XML \
  --xlsx-only

# Option 2: Entire mapplets folder (recommended)
python -m bldmsttmgen generate \
  --xml input/samples/m_mapping.XML \
  --mapping m_mapping \
  --mapplet-dir input/mapplets/ \
  --xlsx-only
```

Place all mapplet XML files in `input/mapplets/` and always use `--mapplet-dir` to ensure full lineage resolution.

---

## Running Tests

```bash
pip install pytest
pytest tests/ -v
```

---

## GitHub Copilot Agent

Call the agent in VS Code Copilot Chat:
```
@BDLM STTM generate for input/samples/m_TMP_to_SHD.XML
```

See `.github/agents/bldm-sttm.agent.md` for full agent documentation.
