# AGENTS.md — Available Copilot Agents

## BDLM STTM Agent
**File:** `.github/agents/bldm-sttm.agent.md`
**Invoke:** `@BDLM STTM <request>`
**Version:** 1.0 | **Compatible:** bldmsttmgen>=1.0

Generates and validates BLDM STTM artifacts from Informatica PowerCenter XML exports.

| Task | Example |
|---|---|
| Generate STTM | `@BDLM STTM generate for input/samples/m_TMP_to_SHD.XML` |
| List mappings | `@BDLM STTM what mappings are in m_TMP_to_SHD.XML?` |
| Explain output | `@BDLM STTM explain the joins in STTM_TGT_SHD.xlsx` |
| Troubleshoot | `@BDLM STTM getting openpyxl error, help fix` |

**Prompt used:** `.github/prompts/generateInformaticaBLDMSTTM.prompt.md`
**Output:** `output/bldmsttm/STTM_<TARGET>.xlsx`

---

## SDR Agent (via prompt only — no dedicated agent file)
**Invoke:** Reference `@file:.github/prompts/generateInformaticaSDR.prompt.md`
**Output:** `output/sdr/SDR_<MAPPING>.xlsx`

---

## Local CLI (no Copilot needed)

```bash
# All commands via run.sh
./run.sh sttm   --xml input/samples/m_X.XML --mapping m_X
./run.sh sdr    --xml input/samples/m_X.XML --mapping m_X
./run.sh both   --xml input/samples/m_X.XML --mapping m_X
./run.sh batch  --input input/samples/
./run.sh test
```
