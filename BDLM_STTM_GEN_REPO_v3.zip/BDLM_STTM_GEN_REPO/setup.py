from setuptools import setup, find_packages

setup(
    name="bldmsttmgen",
    version="1.0.0",
    description="BDLM STTM Generator - Informatica PowerCenter XML to STTM documentation",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    python_requires=">=3.8",
    install_requires=[
        "openpyxl>=3.1.0",
    ],
    extras_require={
        "dev": ["pytest>=7.0.0"]
    },
    entry_points={
        "console_scripts": [
            "bldmsttmgen=bldmsttmgen.__main__:main",
        ]
    }
)
