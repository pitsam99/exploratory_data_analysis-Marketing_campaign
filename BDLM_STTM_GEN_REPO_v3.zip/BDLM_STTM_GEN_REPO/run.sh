#!/bin/bash
# ============================================================
#  BDLM STTM Generator - Local Run Script
#  Usage: ./run.sh <command> [options]
# ============================================================

set -e
REPO_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$REPO_DIR"
export PYTHONPATH="$REPO_DIR/src"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'

usage() {
  echo ""
  echo "Usage: ./run.sh <command> [options]"
  echo ""
  echo "Commands:"
  echo "  install                        Install dependencies"
  echo "  test                           Run test suite"
  echo "  list    --xml <file>           List mappings in XML"
  echo "  validate --xml <file>          Validate XML file"
  echo "  sttm    --xml <file> --mapping <name>   Generate STTM"
  echo "  sdr     --xml <file> --mapping <name>   Generate SDR"
  echo "  both    --xml <file> --mapping <name>   Generate STTM + SDR"
  echo "  batch   --input <dir>          Batch generate all XMLs"
  echo ""
  echo "Common options:"
  echo "  --mapplet-dir <dir>    Directory with mapplet XMLs (default: input/mapplets/)"
  echo "  --out-dir <dir>        Output directory"
  echo "  --workers <n>          Parallel workers for batch (default: 4)"
  echo ""
  echo "Examples:"
  echo "  ./run.sh install"
  echo "  ./run.sh test"
  echo "  ./run.sh list --xml input/samples/m_TMP_to_SHD_SD_D_BOOK_AMOUNT.XML"
  echo "  ./run.sh sttm --xml input/samples/m_TMP_to_SHD_SD_D_BOOK_AMOUNT.XML --mapping m_TMP_to_SHD_SD_D_BOOK_AMOUNT"
  echo "  ./run.sh both --xml input/samples/m_TMP_to_SHD_SD_D_BOOK_AMOUNT.XML --mapping m_TMP_to_SHD_SD_D_BOOK_AMOUNT"
  echo "  ./run.sh batch --input input/samples/ --workers 4"
  echo ""
}

# ── Parse arguments ──────────────────────────────────────────
COMMAND="${1:-help}"; shift || true
XML=""; MAPPING=""; MAPPLET_DIR="input/mapplets"; OUT_DIR=""; INPUT_DIR=""; WORKERS=4

while [[ $# -gt 0 ]]; do
  case "$1" in
    --xml)          XML="$2";         shift 2 ;;
    --mapping)      MAPPING="$2";     shift 2 ;;
    --mapplet-dir)  MAPPLET_DIR="$2"; shift 2 ;;
    --out-dir)      OUT_DIR="$2";     shift 2 ;;
    --input)        INPUT_DIR="$2";   shift 2 ;;
    --workers)      WORKERS="$2";     shift 2 ;;
    *) echo -e "${RED}Unknown option: $1${NC}"; usage; exit 1 ;;
  esac
done

# ── Commands ─────────────────────────────────────────────────
case "$COMMAND" in

  install)
    echo -e "${GREEN}Installing dependencies...${NC}"
    pip install -r requirements.txt
    pip install -e .
    echo -e "${GREEN}✓ Done${NC}"
    ;;

  test)
    echo -e "${GREEN}Running tests...${NC}"
    pytest tests/ -v
    ;;

  list)
    [[ -z "$XML" ]] && { echo -e "${RED}--xml required${NC}"; usage; exit 1; }
    python -m bldmsttmgen list --xml "$XML"
    ;;

  validate)
    [[ -z "$XML" ]] && { echo -e "${RED}--xml required${NC}"; usage; exit 1; }
    python -m bldmsttmgen validate --xml "$XML" --mapplet-dir "$MAPPLET_DIR"
    ;;

  sttm)
    [[ -z "$XML" || -z "$MAPPING" ]] && { echo -e "${RED}--xml and --mapping required${NC}"; usage; exit 1; }
    OUT="${OUT_DIR:-output/bldmsttm}"
    python -m bldmsttmgen validate --xml "$XML" --mapplet-dir "$MAPPLET_DIR"
    python -m bldmsttmgen generate \
      --xml "$XML" \
      --mapping "$MAPPING" \
      --mapplet-dir "$MAPPLET_DIR" \
      --out-dir "$OUT" \
      --xlsx-only
    echo -e "${GREEN}✓ STTM written to $OUT/${NC}"
    ;;

  sdr)
    [[ -z "$XML" || -z "$MAPPING" ]] && { echo -e "${RED}--xml and --mapping required${NC}"; usage; exit 1; }
    OUT="${OUT_DIR:-output/sdr}"
    python -m sdrgen generate \
      --xml "$XML" \
      --mapping "$MAPPING" \
      --mapplet-dir "$MAPPLET_DIR" \
      --out-dir "$OUT"
    echo -e "${GREEN}✓ SDR written to $OUT/${NC}"
    ;;

  both)
    [[ -z "$XML" || -z "$MAPPING" ]] && { echo -e "${RED}--xml and --mapping required${NC}"; usage; exit 1; }
    python -m bldmsttmgen validate --xml "$XML" --mapplet-dir "$MAPPLET_DIR"
    python -m bldmsttmgen generate \
      --xml "$XML" --mapping "$MAPPING" \
      --mapplet-dir "$MAPPLET_DIR" \
      --out-dir "${OUT_DIR:-output/bldmsttm}" --xlsx-only
    python -m sdrgen generate \
      --xml "$XML" --mapping "$MAPPING" \
      --mapplet-dir "$MAPPLET_DIR" \
      --out-dir "${OUT_DIR:-output/sdr}"
    echo -e "${GREEN}✓ STTM + SDR generated${NC}"
    ;;

  batch)
    [[ -z "$INPUT_DIR" ]] && { echo -e "${RED}--input required${NC}"; usage; exit 1; }
    OUT="${OUT_DIR:-output/bldmsttm}"
    python -m bldmsttmgen batch \
      --input "$INPUT_DIR" \
      --pattern "*.XML" \
      --mapplet-dir "$MAPPLET_DIR" \
      --workers "$WORKERS" \
      --out-dir "$OUT" \
      --xlsx-only
    echo -e "${GREEN}✓ Batch complete — outputs in $OUT/${NC}"
    ;;

  help|--help|-h)
    usage
    ;;

  *)
    echo -e "${RED}Unknown command: $COMMAND${NC}"
    usage
    exit 1
    ;;
esac
