# BLDM Architecture Reference

## Overview
Basel/Lending Data Mart (BLDM) is a centralized, historical repository providing a "single version of the truth."

## Data Flow
```
InboundFiles → Staging (TPR) → Temp (TMP) → DDM
```

## Layers

### TPR (Time Persistent Repository)
- Source-mimicking schemas storing full snapshots by period-end date
- Mixed daily/monthly/quarterly snapshots
- Keeps ~7 days rolling plus month-end snapshots
- Partitioned by `TPR_AS_OF_DT`
- Uses stitching approach for incremental/delta sources

### TMP (Temp Layer)
- Flattened fact/dim views
- Intermediate staging between TPR and DDM

### DDM (Dimensional Data Mart)
- Star schema: Facts + Dimensions sourced from TPR and RRDW STG
- Keeps current month-to-date daily snapshots + historical month-end snapshots
- Enables cross-portfolio reporting

## DDM Load Process (8 Steps)
1. Transform to TMP "flattened" fact/dim views
2. Load dimension data to Shadow
3. Load Shadow to DDM
4. Load "big dimensions"
5. Build temp fact
6. Populate fact via partition swap
7. Report/update orphan dimension values
8. Load dimensions/facts similarly

## Operational Controls
- TPR reconciliation: `SRC_AUDIT` / `TGT_AUDIT` → test results table (marks runs success/failure)
- Shadow process auto-inserts `!UNK` for orphan dimension codes
- Business stewards enrich codes/descriptions/hierarchies

## Mapping Types
| Type | Description |
|---|---|
| FILE to TPR | Raw file ingestion into TPR layer |
| TPR to TMP | Time-persistent to temp flattening |
| TMP to DIM/FACT/SHADOW | Dimensional loading |
| Mapplets | Reusable transformation logic |
