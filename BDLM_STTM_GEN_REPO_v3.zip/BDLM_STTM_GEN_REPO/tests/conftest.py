"""
Shared pytest fixtures for all test modules.
"""

import pytest
import os
import sys

# Ensure src is on path for all tests
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))


MINIMAL_XML = """<?xml version="1.0" encoding="UTF-8"?>
<POWERMART>
  <REPOSITORY NAME="TEST">
    <FOLDER NAME="FOLDER_A">
      <MAPPING NAME="m_TEST_MAPPING">
        <TRANSFORMATION NAME="SQ_SRC" TYPE="Source Qualifier">
          <TABLEATTRIBUTE NAME="Sql Query" VALUE="SELECT ID, NAME FROM SCHEMA_A.TABLE_A WHERE DT &gt;= $$START_DATE"/>
          <TRANSFORMFIELD NAME="ID"   DATATYPE="decimal" PRECISION="18" SCALE="0" PORTTYPE="OUTPUT"/>
          <TRANSFORMFIELD NAME="NAME" DATATYPE="varchar" PRECISION="100" SCALE="0" PORTTYPE="OUTPUT"/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="TGT_A" TYPE="Target Definition">
          <TRANSFORMFIELD NAME="ID"   DATATYPE="decimal" PRECISION="18" SCALE="0" PORTTYPE="INPUT"/>
          <TRANSFORMFIELD NAME="NAME" DATATYPE="varchar" PRECISION="100" SCALE="0" PORTTYPE="INPUT"/>
        </TRANSFORMATION>
        <CONNECTOR FROMINSTANCE="SQ_SRC" FROMFIELD="ID"   TOINSTANCE="TGT_A" TOFIELD="ID"/>
        <CONNECTOR FROMINSTANCE="SQ_SRC" FROMFIELD="NAME" TOINSTANCE="TGT_A" TOFIELD="NAME"/>
      </MAPPING>
    </FOLDER>
  </REPOSITORY>
</POWERMART>"""


@pytest.fixture(scope="session")
def minimal_xml_path(tmp_path_factory):
    """Minimal valid XML — reused across all test modules."""
    p = tmp_path_factory.mktemp("xml") / "m_TEST_MAPPING.XML"
    p.write_text(MINIMAL_XML)
    return str(p)


@pytest.fixture(scope="session")
def sample_xml_path():
    """Real sample XML shipped with the repo."""
    path = os.path.join(
        os.path.dirname(__file__), "..",
        "input", "samples", "m_TMP_to_SHD_SD_D_BOOK_AMOUNT.XML"
    )
    if os.path.exists(path):
        return path
    return None


@pytest.fixture(scope="session")
def mapplet_dir():
    return os.path.join(os.path.dirname(__file__), "..", "input", "mapplets")
