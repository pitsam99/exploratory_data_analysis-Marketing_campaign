"""
Test Suite for BDLM STTM Generator
Run: pytest tests/ -v
"""

import pytest
import os
import sys
import xml.etree.ElementTree as ET

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from bldmsttmgen.parser import InformaticaXMLParser
from bldmsttmgen.excel_writer import STTMExcelWriter
from bldmsttmgen.generator import MappingAnalyzer, _extract_target_table


# ── Fixtures ──────────────────────────────────────────────────

SAMPLE_XML = """<?xml version="1.0" encoding="UTF-8"?>
<POWERMART>
  <REPOSITORY NAME="TEST_REPO">
    <FOLDER NAME="TEST_FOLDER">
      <MAPPING NAME="m_TMP_to_SHD_TEST">
        <TRANSFORMATION NAME="SQ_SOURCE" TYPE="Source Qualifier">
          <TABLEATTRIBUTE NAME="Sql Query" VALUE="SELECT A.COL1, B.COL2 FROM TABLE_A A INNER JOIN TABLE_B B ON A.ID = B.ID WHERE A.DT &gt;= $$START_DATE"/>
          <TABLEATTRIBUTE NAME="Join Condition" VALUE="TABLE_A.ID = TABLE_B.ID"/>
          <TRANSFORMFIELD NAME="COL1" DATATYPE="varchar" PRECISION="50" SCALE="0" PORTTYPE="OUTPUT"/>
          <TRANSFORMFIELD NAME="COL2" DATATYPE="decimal" PRECISION="18" SCALE="2" PORTTYPE="OUTPUT"/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="EXP_CALC" TYPE="Expression">
          <TRANSFORMFIELD NAME="COL1_IN" DATATYPE="varchar" PRECISION="50" SCALE="0" PORTTYPE="INPUT" EXPRESSION=""/>
          <TRANSFORMFIELD NAME="COL1_OUT" DATATYPE="varchar" PRECISION="50" SCALE="0" PORTTYPE="OUTPUT" EXPRESSION="RTRIM(LTRIM(COL1_IN))"/>
          <TRANSFORMFIELD NAME="LOAD_DT" DATATYPE="date/time" PRECISION="29" SCALE="9" PORTTYPE="OUTPUT" EXPRESSION="SYSDATE"/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="TGT_TABLE" TYPE="Target Definition">
          <TRANSFORMFIELD NAME="COL1" DATATYPE="varchar" PRECISION="50" SCALE="0" PORTTYPE="INPUT"/>
          <TRANSFORMFIELD NAME="COL2" DATATYPE="decimal" PRECISION="18" SCALE="2" PORTTYPE="INPUT"/>
          <TRANSFORMFIELD NAME="LOAD_DT" DATATYPE="date/time" PRECISION="29" SCALE="9" PORTTYPE="INPUT"/>
        </TRANSFORMATION>
        <CONNECTOR FROMINSTANCE="SQ_SOURCE" FROMFIELD="COL1" TOINSTANCE="EXP_CALC" TOFIELD="COL1_IN"/>
        <CONNECTOR FROMINSTANCE="EXP_CALC" FROMFIELD="COL1_OUT" TOINSTANCE="TGT_TABLE" TOFIELD="COL1"/>
        <CONNECTOR FROMINSTANCE="SQ_SOURCE" FROMFIELD="COL2" TOINSTANCE="TGT_TABLE" TOFIELD="COL2"/>
        <CONNECTOR FROMINSTANCE="EXP_CALC" FROMFIELD="LOAD_DT" TOINSTANCE="TGT_TABLE" TOFIELD="LOAD_DT"/>
      </MAPPING>
    </FOLDER>
  </REPOSITORY>
</POWERMART>"""


@pytest.fixture
def sample_xml_path(tmp_path):
    """Create a sample XML file for testing."""
    xml_file = tmp_path / "m_TMP_to_SHD_TEST.XML"
    xml_file.write_text(SAMPLE_XML)
    return str(xml_file)


@pytest.fixture
def parser(sample_xml_path):
    return InformaticaXMLParser(sample_xml_path)


# ── Parser Tests ──────────────────────────────────────────────

class TestParser:
    def test_validates_powermart_root(self, sample_xml_path):
        parser = InformaticaXMLParser(sample_xml_path)
        assert parser.root.tag == "POWERMART"

    def test_rejects_invalid_xml(self, tmp_path):
        bad = tmp_path / "bad.XML"
        bad.write_text("<NOT_INFORMATICA><foo/></NOT_INFORMATICA>")
        with pytest.raises(ValueError, match="POWERMART"):
            InformaticaXMLParser(str(bad))

    def test_rejects_missing_file(self):
        with pytest.raises(FileNotFoundError):
            InformaticaXMLParser("/nonexistent/path.XML")

    def test_list_mappings(self, parser):
        mappings = parser.list_mappings()
        assert "m_TMP_to_SHD_TEST" in mappings
        assert len(mappings) == 1

    def test_parse_mapping_metadata(self, parser):
        meta = parser.parse_mapping("m_TMP_to_SHD_TEST")
        assert meta.name == "m_TMP_to_SHD_TEST"
        assert meta.folder == "TEST_FOLDER"

    def test_parse_transformations(self, parser):
        meta = parser.parse_mapping("m_TMP_to_SHD_TEST")
        types = [t.type for t in meta.transformations]
        assert "Source Qualifier" in types
        assert "Expression" in types
        assert "Target Definition" in types

    def test_sql_query_extracted(self, parser):
        meta = parser.parse_mapping("m_TMP_to_SHD_TEST")
        sq = next(t for t in meta.transformations if t.type == "Source Qualifier")
        assert "SELECT" in sq.sql_query
        assert "TABLE_A" in sq.sql_query

    def test_xml_entities_decoded(self, parser):
        """&gt; should be decoded to > in SQL"""
        meta = parser.parse_mapping("m_TMP_to_SHD_TEST")
        sq = next(t for t in meta.transformations if t.type == "Source Qualifier")
        assert ">=" in sq.sql_query
        assert "&gt;" not in sq.sql_query

    def test_parameters_extracted(self, parser):
        meta = parser.parse_mapping("m_TMP_to_SHD_TEST")
        assert "$$START_DATE" in meta.parameters

    def test_connectors_parsed(self, parser):
        meta = parser.parse_mapping("m_TMP_to_SHD_TEST")
        assert len(meta.connectors) > 0

    def test_invalid_mapping_name(self, parser):
        with pytest.raises(ValueError, match="not found"):
            parser.parse_mapping("NONEXISTENT_MAPPING")

    def test_source_qualifier_sql_list(self, parser):
        results = parser.get_source_qualifier_sql("m_TMP_to_SHD_TEST")
        assert len(results) == 1
        assert results[0]["rule_id"] == "R001"


# ── Analyzer Tests ────────────────────────────────────────────

class TestAnalyzer:
    def test_analysis_returns_all_sections(self, parser):
        meta = parser.parse_mapping("m_TMP_to_SHD_TEST")
        analyzer = MappingAnalyzer(meta, parser)
        analysis = analyzer.analyze()

        required = ["overview", "mapping_table", "sql_queries",
                    "joins", "rules", "field_lineage",
                    "mapplet_dependencies", "warnings"]
        for key in required:
            assert key in analysis, f"Missing section: {key}"

    def test_overview_populated(self, parser):
        meta = parser.parse_mapping("m_TMP_to_SHD_TEST")
        analyzer = MappingAnalyzer(meta, parser)
        overview = analyzer._build_overview()
        assert overview["mapping_name"] == "m_TMP_to_SHD_TEST"
        assert overview["folder"] == "TEST_FOLDER"

    def test_mapping_table_has_target_columns(self, parser):
        meta = parser.parse_mapping("m_TMP_to_SHD_TEST")
        analyzer = MappingAnalyzer(meta, parser)
        rows = analyzer._build_mapping_table()
        cols = [r["target_column"] for r in rows]
        assert "COL1" in cols
        assert "COL2" in cols

    def test_sysdate_marked_as_const(self, parser):
        meta = parser.parse_mapping("m_TMP_to_SHD_TEST")
        analyzer = MappingAnalyzer(meta, parser)
        assert analyzer._is_constant("SYSDATE") is True
        assert analyzer._is_constant("NULL") is True
        assert analyzer._is_constant("'fixed_string'") is True
        assert analyzer._is_constant("42") is True
        assert analyzer._is_constant("COL1 || COL2") is False

    def test_sql_queries_have_rule_ids(self, parser):
        meta = parser.parse_mapping("m_TMP_to_SHD_TEST")
        analyzer = MappingAnalyzer(meta, parser)
        rows = analyzer._build_sql_queries()
        assert len(rows) > 0
        assert rows[0]["rule_id"] == "R001"


# ── Excel Writer Tests ────────────────────────────────────────

class TestExcelWriter:
    def test_creates_xlsx_file(self, tmp_path):
        output = str(tmp_path / "test_output" / "STTM_TEST.xlsx")
        writer = STTMExcelWriter(output)
        writer.write_mapping_overview({"mapping_name": "TEST", "folder": "F"})
        writer.write_sttm_mapping_table([])
        writer.write_sql_query([])
        writer.write_joins([])
        writer.write_rules([])
        writer.write_field_lineage([])
        writer.write_mapplet_dependencies([])
        writer.save()
        assert os.path.exists(output)

    def test_workbook_has_7_sheets(self, tmp_path):
        import openpyxl
        output = str(tmp_path / "STTM_TEST.xlsx")
        writer = STTMExcelWriter(output)
        writer.write_mapping_overview({})
        writer.write_sttm_mapping_table([])
        writer.write_sql_query([])
        writer.write_joins([])
        writer.write_rules([])
        writer.write_field_lineage([])
        writer.write_mapplet_dependencies([])
        writer.save()

        wb = openpyxl.load_workbook(output)
        assert len(wb.sheetnames) == 7


# ── Integration Test ──────────────────────────────────────────

class TestEndToEnd:
    def test_full_generate(self, sample_xml_path, tmp_path):
        from bldmsttmgen.generator import generate
        output = generate(
            xml_path=sample_xml_path,
            mapping_name="m_TMP_to_SHD_TEST",
            out_dir=str(tmp_path / "output"),
            xlsx_only=True
        )
        assert os.path.exists(output)
        assert output.endswith(".xlsx")
        assert "STTM_" in os.path.basename(output)
