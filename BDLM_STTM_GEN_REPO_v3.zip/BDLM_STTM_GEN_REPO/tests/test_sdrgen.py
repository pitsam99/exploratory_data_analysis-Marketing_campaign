"""
Test Suite for SDR Generator
Run: pytest tests/test_sdrgen.py -v
"""

import pytest
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from sdrgen.sdr_generator import SDRAnalyzer, generate_sdr
from sdrgen.sdr_excel_writer import SDRExcelWriter
from bldmsttmgen.parser import InformaticaXMLParser


@pytest.fixture
def parser(minimal_xml_path):
    return InformaticaXMLParser(minimal_xml_path)


@pytest.fixture
def analyzer(minimal_xml_path):
    p = InformaticaXMLParser(minimal_xml_path)
    meta = p.parse_mapping("m_TEST_MAPPING")
    return SDRAnalyzer(meta, p)


class TestSDRAnalyzer:
    def test_analysis_has_all_sections(self, analyzer):
        result = analyzer.analyze()
        for key in ["source_overview", "source_fields", "filters",
                    "dependencies", "dq_rules"]:
            assert key in result

    def test_source_fields_extracted(self, analyzer):
        fields = analyzer._build_source_fields()
        names = [f["field_name"] for f in fields]
        assert "ID" in names
        assert "NAME" in names

    def test_table_extracted_from_sql(self, analyzer):
        tables = analyzer._extract_tables_from_sql(
            "SELECT A.ID FROM SCHEMA_A.TABLE_A A JOIN SCHEMA_B.TABLE_B B ON A.ID = B.ID"
        )
        assert any("TABLE_A" in t for t in tables)
        assert any("TABLE_B" in t for t in tables)

    def test_where_clause_extracted(self, analyzer):
        sql = "SELECT ID FROM TABLE_A WHERE DT >= SYSDATE AND STATUS = 'Y'"
        where = analyzer._extract_where_clause(sql)
        assert "DT >=" in where
        assert "STATUS" in where

    def test_parameter_in_dq_rules(self, analyzer):
        rules = analyzer._build_dq_rules()
        param_rules = [r for r in rules if r["rule_type"] == "Parameter Guard"]
        assert len(param_rules) > 0
        assert any("$$START_DATE" in r["field"] for r in param_rules)

    def test_dependencies_include_source_tables(self, analyzer):
        deps = analyzer._build_dependencies()
        types = [d["dependency_type"] for d in deps]
        assert "Source Table" in types


class TestSDRExcelWriter:
    def test_creates_5_sheets(self, tmp_path):
        import openpyxl
        output = str(tmp_path / "SDR_TEST.xlsx")
        writer = SDRExcelWriter(output)
        writer.write_source_overview([])
        writer.write_source_fields([])
        writer.write_filters_conditions([])
        writer.write_source_dependencies([])
        writer.write_data_quality_rules([])
        writer.save()
        wb = openpyxl.load_workbook(output)
        assert len(wb.sheetnames) == 5

    def test_output_file_created(self, tmp_path):
        output = str(tmp_path / "SDR_TEST.xlsx")
        writer = SDRExcelWriter(output)
        writer.write_source_overview([{"source_system": "Test", "schema": "S",
            "table_or_view": "T", "full_name": "S.T",
            "extraction_method": "SQL", "sq_transformation": "SQ", "description": ""}])
        writer.write_source_fields([])
        writer.write_filters_conditions([])
        writer.write_source_dependencies([])
        writer.write_data_quality_rules([])
        writer.save()
        assert os.path.exists(output)


class TestSDREndToEnd:
    def test_full_sdr_generate(self, minimal_xml_path, tmp_path):
        output = generate_sdr(
            xml_path=minimal_xml_path,
            mapping_name="m_TEST_MAPPING",
            out_dir=str(tmp_path / "output")
        )
        assert os.path.exists(output)
        assert "SDR_" in os.path.basename(output)
        assert output.endswith(".xlsx")

    def test_sdr_on_real_sample(self, sample_xml_path, tmp_path):
        if not sample_xml_path:
            pytest.skip("Sample XML not available")
        output = generate_sdr(
            xml_path=sample_xml_path,
            mapping_name="m_TMP_to_SHD_SD_D_BOOK_AMOUNT",
            out_dir=str(tmp_path / "output")
        )
        assert os.path.exists(output)
