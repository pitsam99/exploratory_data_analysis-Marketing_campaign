"""
SDR Excel Writer
Generates professional SDR XLSX with 5 worksheets.
Blue theme (distinct from STTM green theme).
"""

import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from typing import List, Dict, Any
import os

HEADER_BG    = "1A3A5C"
HEADER_FG    = "FFFFFF"
ALT_ROW_BG   = "E8EEF4"
BORDER_COLOR = "A0B4C8"


def _side():
    return Side(style="thin", color=BORDER_COLOR)

def _border():
    s = _side()
    return Border(left=s, right=s, top=s, bottom=s)

def _apply(cell, fill_color, bold=False, wrap=True, center=False):
    cell.fill = PatternFill("solid", fgColor=fill_color)
    cell.font = Font(
        bold=bold,
        color=HEADER_FG if fill_color == HEADER_BG else "000000",
        name="Calibri", size=10 if bold else 9
    )
    cell.alignment = Alignment(
        horizontal="center" if center else "left",
        vertical="top", wrap_text=wrap
    )
    cell.border = _border()


def _write_sheet(ws, headers: List[str], rows: List[List[Any]]):
    for col, h in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=h)
        _apply(cell, HEADER_BG, bold=True, center=True)
    ws.freeze_panes = "A2"
    ws.row_dimensions[1].height = 28

    for ri, row in enumerate(rows, 2):
        bg = ALT_ROW_BG if ri % 2 == 0 else "FFFFFF"
        for ci, val in enumerate(row, 1):
            cell = ws.cell(row=ri, column=ci, value=str(val) if val else "")
            _apply(cell, bg)

    for col in range(1, len(headers) + 1):
        max_len = len(headers[col - 1])
        for row in ws.iter_rows(min_row=2, min_col=col, max_col=col):
            for c in row:
                if c.value:
                    max_len = max(max_len, min(len(str(c.value)), 55))
        ws.column_dimensions[get_column_letter(col)].width = max_len + 4


class SDRExcelWriter:
    def __init__(self, output_path: str):
        self.output_path = output_path
        self.wb = openpyxl.Workbook()
        self.wb.remove(self.wb.active)

    def write_source_overview(self, rows: List[Dict]):
        ws = self.wb.create_sheet("Source Overview")
        headers = ["Source System", "Schema", "Table / View", "Full Name",
                   "Extraction Method", "SQ Transformation", "Description"]
        _write_sheet(ws, headers, [
            [r.get("source_system",""), r.get("schema",""), r.get("table_or_view",""),
             r.get("full_name",""), r.get("extraction_method",""),
             r.get("sq_transformation",""), r.get("description","")]
            for r in rows
        ])

    def write_source_fields(self, rows: List[Dict]):
        ws = self.wb.create_sheet("Source Fields")
        headers = ["Transformation", "Field Name", "Data Type",
                   "Precision", "Scale", "Nullable", "Primary Key", "Description"]
        _write_sheet(ws, headers, [
            [r.get("transformation",""), r.get("field_name",""), r.get("datatype",""),
             r.get("precision",""), r.get("scale",""), r.get("nullable",""),
             r.get("primary_key",""), r.get("description","")]
            for r in rows
        ])

    def write_filters_conditions(self, rows: List[Dict]):
        ws = self.wb.create_sheet("Filters & Conditions")
        headers = ["Filter ID", "Transformation", "Filter Type",
                   "Condition", "Parameters Used", "Notes"]
        _write_sheet(ws, headers, [
            [r.get("filter_id",""), r.get("transformation",""), r.get("filter_type",""),
             r.get("condition",""), r.get("parameters_used",""), r.get("notes","")]
            for r in rows
        ])

    def write_source_dependencies(self, rows: List[Dict]):
        ws = self.wb.create_sheet("Source Dependencies")
        headers = ["Dependency Type", "Object Name", "Schema",
                   "Referenced In", "Notes"]
        _write_sheet(ws, headers, [
            [r.get("dependency_type",""), r.get("object_name",""), r.get("schema",""),
             r.get("referenced_in",""), r.get("notes","")]
            for r in rows
        ])

    def write_data_quality_rules(self, rows: List[Dict]):
        ws = self.wb.create_sheet("Data Quality Rules")
        headers = ["DQ ID", "Rule Type", "Field", "Condition", "Source", "Notes"]
        _write_sheet(ws, headers, [
            [r.get("dq_id",""), r.get("rule_type",""), r.get("field",""),
             r.get("condition",""), r.get("source",""), r.get("notes","")]
            for r in rows
        ])

    def save(self) -> str:
        os.makedirs(os.path.dirname(self.output_path), exist_ok=True)
        self.wb.save(self.output_path)
        print(f"[OK] Saved: {self.output_path}")
        return self.output_path
