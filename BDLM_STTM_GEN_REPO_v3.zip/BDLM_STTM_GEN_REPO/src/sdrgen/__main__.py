"""
SDR Generator CLI
Usage:
  python -m sdrgen generate --xml <XML> --mapping <NAME>
  python -m sdrgen list --xml <XML>
"""

import argparse
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


def cmd_generate(args):
    from sdrgen.sdr_generator import generate_sdr
    output = generate_sdr(
        xml_path=args.xml,
        mapping_name=args.mapping,
        out_dir=args.out_dir,
        mapplet_dir=args.mapplet_dir,
    )
    print(f"\nOutput: {output}")


def cmd_list(args):
    from bldmsttmgen.parser import InformaticaXMLParser
    parser = InformaticaXMLParser(args.xml)
    mappings = parser.list_mappings()
    print(f"\nMappings in {args.xml}:")
    for i, m in enumerate(mappings, 1):
        print(f"  {i:2d}. {m}")


def main():
    parser = argparse.ArgumentParser(
        prog="sdrgen",
        description="SDR Generator — Informatica PowerCenter XML → SDR XLSX"
    )
    subparsers = parser.add_subparsers(dest="command")
    subparsers.required = True

    gen_p = subparsers.add_parser("generate", help="Generate SDR")
    gen_p.add_argument("--xml",         required=True)
    gen_p.add_argument("--mapping",     required=True)
    gen_p.add_argument("--out-dir",     default="output/sdr")
    gen_p.add_argument("--mapplet-dir", default=None)
    gen_p.set_defaults(func=cmd_generate)

    lst_p = subparsers.add_parser("list", help="List mappings")
    lst_p.add_argument("--xml", required=True)
    lst_p.set_defaults(func=cmd_list)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
