"""
SDR Generator
Generates Source Data Requirements (SDR) documentation
from Informatica PowerCenter XML exports.
"""

from .sdr_generator import generate_sdr
from .sdr_excel_writer import SDRExcelWriter

__version__ = "1.0.0"
__all__ = ["generate_sdr", "SDRExcelWriter"]
