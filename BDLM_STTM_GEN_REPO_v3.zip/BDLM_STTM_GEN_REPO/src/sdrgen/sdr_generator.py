"""
SDR Generator - Source Data Requirements
Extracts source system requirements from Informatica XML exports.
"""

import os
import sys
import re
from typing import List, Dict, Optional

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from bldmsttmgen.parser import InformaticaXMLParser
from .sdr_excel_writer import SDRExcelWriter


def generate_sdr(
    xml_path: str,
    mapping_name: str,
    out_dir: str = "output/sdr",
    mapplet_dir: Optional[str] = None,
) -> str:
    """
    Generate SDR documentation for a single mapping.

    Returns: Path to generated XLSX file
    """
    print(f"\n{'='*60}")
    print(f"  SDR Generator v1.0")
    print(f"{'='*60}")
    print(f"  XML:     {xml_path}")
    print(f"  Mapping: {mapping_name}")
    print(f"{'='*60}\n")

    # Parse
    print("[1/3] Parsing XML...")
    parser = InformaticaXMLParser(xml_path, mapplet_dir=mapplet_dir)
    metadata = parser.parse_mapping(mapping_name)

    # Analyze sources
    print("[2/3] Analyzing source requirements...")
    analyzer = SDRAnalyzer(metadata, parser)
    analysis = analyzer.analyze()

    # Write
    output_path = os.path.join(out_dir, f"SDR_{mapping_name}.xlsx")
    print("[3/3] Writing SDR Excel...")
    writer = SDRExcelWriter(output_path)
    writer.write_source_overview(analysis["source_overview"])
    writer.write_source_fields(analysis["source_fields"])
    writer.write_filters_conditions(analysis["filters"])
    writer.write_source_dependencies(analysis["dependencies"])
    writer.write_data_quality_rules(analysis["dq_rules"])
    path = writer.save()

    print(f"\n✓ SDR complete: {path}")
    return path


class SDRAnalyzer:
    """Analyzes mapping metadata for source data requirements."""

    def __init__(self, metadata, parser):
        self.metadata = metadata
        self.parser = parser

    def analyze(self) -> Dict:
        return {
            "source_overview":  self._build_source_overview(),
            "source_fields":    self._build_source_fields(),
            "filters":          self._build_filters(),
            "dependencies":     self._build_dependencies(),
            "dq_rules":         self._build_dq_rules(),
        }

    def _build_source_overview(self) -> List[Dict]:
        rows = []
        for t in self.metadata.transformations:
            if t.type == "Source Qualifier":
                # Extract table names from SQL
                tables = self._extract_tables_from_sql(t.sql_query)
                for tbl in tables:
                    parts = tbl.split(".")
                    schema = parts[0] if len(parts) > 1 else ""
                    table  = parts[-1]
                    rows.append({
                        "source_system":     "Informatica PowerCenter",
                        "schema":            schema,
                        "table_or_view":     table,
                        "full_name":         tbl,
                        "extraction_method": "SQL Override" if t.sql_query else "Default SELECT",
                        "sq_transformation": t.name,
                        "description":       f"Source table referenced in {t.name}",
                    })
        return rows

    def _build_source_fields(self) -> List[Dict]:
        rows = []
        for t in self.metadata.transformations:
            if t.type == "Source Qualifier":
                for port in t.ports:
                    rows.append({
                        "transformation":  t.name,
                        "field_name":      port.name,
                        "datatype":        port.datatype,
                        "precision":       port.precision,
                        "scale":           port.scale,
                        "nullable":        "YES",
                        "primary_key":     "NO",
                        "description":     port.description or "",
                    })
        return rows

    def _build_filters(self) -> List[Dict]:
        rows = []
        counter = 1
        for t in self.metadata.transformations:
            if t.type == "Source Qualifier" and t.sql_query:
                where_clause = self._extract_where_clause(t.sql_query)
                if where_clause:
                    rows.append({
                        "filter_id":       f"F{counter:03d}",
                        "transformation":  t.name,
                        "filter_type":     "WHERE Clause",
                        "condition":       where_clause,
                        "parameters_used": ", ".join(re.findall(r'\$\$\w+', where_clause)),
                        "notes":           "",
                    })
                    counter += 1
            if t.type == "Filter":
                for attr in []:  # would parse filter condition
                    pass
        return rows

    def _build_dependencies(self) -> List[Dict]:
        rows = []
        seen = set()
        for t in self.metadata.transformations:
            if t.type == "Source Qualifier" and t.sql_query:
                tables = self._extract_tables_from_sql(t.sql_query)
                for tbl in tables:
                    if tbl not in seen:
                        seen.add(tbl)
                        rows.append({
                            "dependency_type": "Source Table",
                            "object_name":     tbl,
                            "schema":          tbl.split(".")[0] if "." in tbl else "",
                            "referenced_in":   t.name,
                            "notes":           "",
                        })
            if "Lookup" in t.type and t.lookup_table:
                if t.lookup_table not in seen:
                    seen.add(t.lookup_table)
                    rows.append({
                        "dependency_type": "Lookup Table",
                        "object_name":     t.lookup_table,
                        "schema":          t.lookup_table.split(".")[0] if "." in t.lookup_table else "",
                        "referenced_in":   t.name,
                        "notes":           t.lookup_condition[:100] if t.lookup_condition else "",
                    })
        for mplt in self.metadata.mapplets:
            rows.append({
                "dependency_type": "Mapplet",
                "object_name":     mplt,
                "schema":          "",
                "referenced_in":   self.metadata.name,
                "notes":           "Reusable transformation dependency",
            })
        return rows

    def _build_dq_rules(self) -> List[Dict]:
        rows = []
        counter = 1
        # Extract NOT NULL / filter constraints from SQL WHERE clauses
        for t in self.metadata.transformations:
            if t.type == "Source Qualifier" and t.sql_query:
                sql_upper = t.sql_query.upper()
                if "IS NOT NULL" in sql_upper:
                    rows.append({
                        "dq_id":       f"DQ{counter:03d}",
                        "rule_type":   "NOT NULL Check",
                        "field":       "See SQL WHERE clause",
                        "condition":   "IS NOT NULL",
                        "source":      t.name,
                        "notes":       "Enforced via Source Qualifier SQL filter",
                    })
                    counter += 1
                if "!=" in t.sql_query or "<>" in t.sql_query:
                    rows.append({
                        "dq_id":       f"DQ{counter:03d}",
                        "rule_type":   "Exclusion Filter",
                        "field":       "See SQL WHERE clause",
                        "condition":   "!= / <> filter applied",
                        "source":      t.name,
                        "notes":       "Records excluded via inequality filter in SQL",
                    })
                    counter += 1
                # Session parameters used as date range guards
                params = re.findall(r'\$\$\w+', t.sql_query)
                for p in params:
                    rows.append({
                        "dq_id":       f"DQ{counter:03d}",
                        "rule_type":   "Parameter Guard",
                        "field":       p,
                        "condition":   f"Session parameter {p} must be set",
                        "source":      t.name,
                        "notes":       "Session parameter controls data range / scope",
                    })
                    counter += 1
        return rows

    def _extract_tables_from_sql(self, sql: str) -> List[str]:
        """Extract table/view names from SQL."""
        if not sql:
            return []
        tables = []
        # Match FROM and JOIN clauses
        pattern = re.compile(
            r'(?:FROM|JOIN)\s+([\w]+\.[\w]+|[\w]+)\s*(?:AS\s+\w+|\w+)?',
            re.IGNORECASE
        )
        for match in pattern.finditer(sql):
            name = match.group(1).strip()
            if name.upper() not in ("SELECT", "WHERE", "ON", "AND", "OR"):
                if name not in tables:
                    tables.append(name)
        return tables

    def _extract_where_clause(self, sql: str) -> str:
        """Extract WHERE clause from SQL."""
        match = re.search(r'\bWHERE\b(.+?)(?:\bORDER\s+BY\b|\bGROUP\s+BY\b|\bHAVING\b|$)',
                          sql, re.IGNORECASE | re.DOTALL)
        if match:
            return match.group(1).strip()
        return ""
