"""
BDLM STTM Generator
Generates Source-to-Target Mapping (STTM) documentation
from Informatica PowerCenter XML exports.
"""

from .generator import generate
from .batch import batch_generate
from .parser import InformaticaXMLParser
from .excel_writer import STTMExcelWriter

__version__ = "1.0.0"
__all__ = ["generate", "batch_generate", "InformaticaXMLParser", "STTMExcelWriter"]
