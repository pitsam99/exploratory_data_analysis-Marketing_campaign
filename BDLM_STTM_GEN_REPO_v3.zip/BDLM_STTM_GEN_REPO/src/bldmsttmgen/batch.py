"""
Batch STTM Generator
Processes multiple XMLs concurrently using ThreadPoolExecutor.
"""

import os
import glob
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Optional, Dict
from .generator import generate
from .parser import InformaticaXMLParser


def batch_generate(
    input_dir: str,
    pattern: str = "*.XML",
    out_dir: str = "output/bldmsttm",
    mapplet_dir: Optional[str] = None,
    workers: int = 4,
    xlsx_only: bool = True
) -> Dict[str, str]:
    """
    Batch generate STTM documents for all XMLs matching a pattern.

    Args:
        input_dir:   Directory containing input XML files
        pattern:     Glob pattern to match XML files
        out_dir:     Output directory
        mapplet_dir: Directory containing mapplet XMLs
        workers:     Number of parallel workers
        xlsx_only:   Output XLSX only

    Returns:
        Dict of {xml_file: output_path or error_message}
    """
    # Find all matching XML files
    search = os.path.join(input_dir, pattern)
    xml_files = glob.glob(search, recursive=False)

    # Also try lowercase extension
    if not xml_files:
        search_lower = os.path.join(input_dir, pattern.lower())
        xml_files = glob.glob(search_lower)

    if not xml_files:
        print(f"[WARN] No files matching '{pattern}' found in {input_dir}")
        return {}

    print(f"\n{'='*60}")
    print(f"  BDLM STTM Batch Generator")
    print(f"  Found {len(xml_files)} XML files")
    print(f"  Workers: {workers}")
    print(f"{'='*60}\n")

    results = {}
    tasks = []

    # Build task list: one task per mapping per XML
    for xml_path in xml_files:
        try:
            parser = InformaticaXMLParser(xml_path, mapplet_dir=mapplet_dir)
            mappings = parser.list_mappings()
            if not mappings:
                results[xml_path] = "ERROR: No mappings found in XML"
                continue
            for mapping_name in mappings:
                tasks.append((xml_path, mapping_name))
        except Exception as e:
            results[xml_path] = f"ERROR: {e}"

    print(f"  Total mappings to process: {len(tasks)}\n")

    # Execute in parallel
    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {
            executor.submit(
                _safe_generate, xml_path, mapping_name,
                out_dir, mapplet_dir, xlsx_only
            ): (xml_path, mapping_name)
            for xml_path, mapping_name in tasks
        }

        for future in as_completed(futures):
            xml_path, mapping_name = futures[future]
            key = f"{os.path.basename(xml_path)}::{mapping_name}"
            try:
                output_path = future.result()
                results[key] = f"OK: {output_path}"
                print(f"  ✓ {key}")
            except Exception as e:
                results[key] = f"ERROR: {e}"
                print(f"  ✗ {key} — {e}")

    # Summary
    ok = sum(1 for v in results.values() if v.startswith("OK"))
    err = sum(1 for v in results.values() if v.startswith("ERROR"))
    print(f"\n{'='*60}")
    print(f"  Batch complete: {ok} succeeded, {err} failed")
    print(f"{'='*60}")

    return results


def _safe_generate(xml_path, mapping_name, out_dir, mapplet_dir, xlsx_only):
    """Wrapper for thread-safe generation with error handling."""
    return generate(
        xml_path=xml_path,
        mapping_name=mapping_name,
        out_dir=out_dir,
        mapplet_dir=mapplet_dir,
        xlsx_only=xlsx_only
    )
