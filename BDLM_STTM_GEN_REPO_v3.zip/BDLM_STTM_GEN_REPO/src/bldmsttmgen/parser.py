"""
Informatica PowerCenter XML Parser
Parses mapping XML exports and extracts all transformation metadata.
"""

import xml.etree.ElementTree as ET
import html
import os
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple


@dataclass
class Port:
    name: str
    datatype: str
    precision: str
    scale: str
    porttype: str  # INPUT, OUTPUT, LOCAL VARIABLE
    expression: str = ""
    description: str = ""


@dataclass
class Transformation:
    name: str
    type: str
    ports: List[Port] = field(default_factory=list)
    sql_query: str = ""
    lookup_table: str = ""
    lookup_condition: str = ""
    join_condition: str = ""
    source_table: str = ""
    source_schema: str = ""


@dataclass
class Connector:
    from_transformation: str
    from_field: str
    to_transformation: str
    to_field: str


@dataclass
class MappingMetadata:
    name: str
    folder: str
    description: str = ""
    transformations: List[Transformation] = field(default_factory=list)
    connectors: List[Connector] = field(default_factory=list)
    mapplets: List[str] = field(default_factory=list)
    parameters: Dict[str, str] = field(default_factory=dict)


class InformaticaXMLParser:
    """
    Parses Informatica PowerCenter XML export files.
    Handles mapplets (embedded + standalone), special characters,
    port naming conventions, variable ports, and shared folder shortcuts.
    """

    def __init__(self, xml_path: str, mapplet_dir: Optional[str] = None,
                 mapplet_xmls: Optional[List[str]] = None):
        self.xml_path = xml_path
        self.mapplet_dir = mapplet_dir
        self.mapplet_xmls = mapplet_xmls or []
        self.tree = None
        self.root = None
        self.mapplet_registry: Dict[str, ET.Element] = {}
        self._load()

    def _load(self):
        """Load and validate XML file."""
        if not os.path.exists(self.xml_path):
            raise FileNotFoundError(f"XML file not found: {self.xml_path}")

        self.tree = ET.parse(self.xml_path)
        self.root = self.tree.getroot()

        # Validate it's an Informatica export
        if self.root.tag != "POWERMART":
            raise ValueError(
                f"Not a valid Informatica PowerCenter export. "
                f"Expected root tag <POWERMART>, got <{self.root.tag}>"
            )

        # Load mapplet registry
        self._load_mapplets()

    def _load_mapplets(self):
        """Register all available mapplet definitions."""
        # 1. Embedded mapplets in current XML
        for mapplet in self.root.iter("MAPPLET"):
            name = mapplet.get("NAME", "")
            if name:
                self.mapplet_registry[name] = mapplet

        # 2. Standalone mapplet XMLs passed explicitly
        for mx in self.mapplet_xmls:
            if os.path.exists(mx):
                self._register_mapplet_from_file(mx)

        # 3. All XMLs in mapplet directory
        if self.mapplet_dir and os.path.isdir(self.mapplet_dir):
            for fname in os.listdir(self.mapplet_dir):
                if fname.upper().endswith(".XML"):
                    self._register_mapplet_from_file(
                        os.path.join(self.mapplet_dir, fname)
                    )

    def _register_mapplet_from_file(self, path: str):
        """Parse a mapplet XML file and register its mapplets."""
        try:
            tree = ET.parse(path)
            root = tree.getroot()
            for mapplet in root.iter("MAPPLET"):
                name = mapplet.get("NAME", "")
                if name and name not in self.mapplet_registry:
                    self.mapplet_registry[name] = mapplet
        except ET.ParseError as e:
            print(f"[WARN] Could not parse mapplet file {path}: {e}")

    def list_mappings(self) -> List[str]:
        """Return all mapping names in the XML."""
        return [
            m.get("NAME", "")
            for m in self.root.iter("MAPPING")
            if m.get("NAME")
        ]

    def parse_mapping(self, mapping_name: str) -> MappingMetadata:
        """Parse a specific mapping and return full metadata."""
        mapping_el = None
        for m in self.root.iter("MAPPING"):
            if m.get("NAME") == mapping_name:
                mapping_el = m
                break

        if mapping_el is None:
            available = self.list_mappings()
            raise ValueError(
                f"Mapping '{mapping_name}' not found. "
                f"Available: {available}"
            )

        folder = self._find_folder(mapping_name)
        metadata = MappingMetadata(
            name=mapping_name,
            folder=folder,
            description=mapping_el.get("DESCRIPTION", "")
        )

        # Parse transformations
        for trans_el in mapping_el.findall("TRANSFORMATION"):
            t = self._parse_transformation(trans_el)
            metadata.transformations.append(t)

        # Parse connectors
        for conn_el in mapping_el.findall("CONNECTOR"):
            c = Connector(
                from_transformation=conn_el.get("FROMINSTANCE", ""),
                from_field=conn_el.get("FROMFIELD", ""),
                to_transformation=conn_el.get("TOINSTANCE", ""),
                to_field=conn_el.get("TOFIELD", "")
            )
            metadata.connectors.append(c)

        # Parse mapplet references
        for inst_el in mapping_el.findall("INSTANCE"):
            if inst_el.get("TYPE") == "MAPPLET":
                mplt_name = inst_el.get("TRANSFORMATION_NAME", "")
                metadata.mapplets.append(mplt_name)

        # Parse parameters
        metadata.parameters = self._extract_parameters(mapping_el)

        return metadata

    def _parse_transformation(self, trans_el: ET.Element) -> Transformation:
        """Parse a single transformation element."""
        t = Transformation(
            name=trans_el.get("NAME", ""),
            type=trans_el.get("TYPE", "")
        )

        # Parse ports
        for port_el in trans_el.findall(".//TRANSFORMFIELD"):
            expr_raw = port_el.get("EXPRESSION", "")
            p = Port(
                name=port_el.get("NAME", ""),
                datatype=port_el.get("DATATYPE", ""),
                precision=port_el.get("PRECISION", ""),
                scale=port_el.get("SCALE", ""),
                porttype=port_el.get("PORTTYPE", ""),
                expression=self._decode_expression(expr_raw),
                description=port_el.get("DESCRIPTION", "")
            )
            t.ports.append(p)

        # Extract SQL query from Source Qualifier
        if t.type == "Source Qualifier":
            for attr_el in trans_el.findall(".//TABLEATTRIBUTE"):
                if attr_el.get("NAME") == "Sql Query":
                    raw = attr_el.get("VALUE", "")
                    t.sql_query = self._decode_expression(raw)
                elif attr_el.get("NAME") == "Join Condition":
                    t.join_condition = self._decode_expression(
                        attr_el.get("VALUE", "")
                    )

        # Extract Lookup details
        elif t.type == "Lookup Procedure" or "Lookup" in t.type:
            for attr_el in trans_el.findall(".//TABLEATTRIBUTE"):
                name = attr_el.get("NAME", "")
                if name == "Lookup table name":
                    t.lookup_table = attr_el.get("VALUE", "")
                elif name == "Lookup Sql Override":
                    t.lookup_condition = self._decode_expression(
                        attr_el.get("VALUE", "")
                    )

        return t

    def _decode_expression(self, raw: str) -> str:
        """XML-decode expression text preserving all special characters."""
        if not raw:
            return ""
        # Decode HTML/XML entities
        decoded = html.unescape(raw)
        # Normalize line breaks (&#xD; → \n)
        decoded = decoded.replace("\r\n", "\n").replace("\r", "\n")
        return decoded

    def _find_folder(self, mapping_name: str) -> str:
        """Find the folder containing a mapping."""
        for folder_el in self.root.iter("FOLDER"):
            for m in folder_el.findall("MAPPING"):
                if m.get("NAME") == mapping_name:
                    return folder_el.get("NAME", "")
        return "Unknown"

    def _extract_parameters(self, mapping_el: ET.Element) -> Dict[str, str]:
        """Extract session parameters ($$PARAM_NAME) from mapping."""
        params = {}
        import re
        pattern = re.compile(r'\$\$(\w+)')

        for trans_el in mapping_el.findall(".//TRANSFORMATION"):
            for attr_el in trans_el.findall(".//TABLEATTRIBUTE"):
                val = attr_el.get("VALUE", "")
                for match in pattern.finditer(val):
                    param_name = f"$${match.group(1)}"
                    if param_name not in params:
                        params[param_name] = "Parameter - document usage"

        return params

    def resolve_mapplet_lineage(self, mapplet_name: str) -> Optional[ET.Element]:
        """Resolve a mapplet's internal definition."""
        if mapplet_name in self.mapplet_registry:
            return self.mapplet_registry[mapplet_name]
        return None

    def get_source_qualifier_sql(self, mapping_name: str) -> List[Dict]:
        """Extract all Source Qualifier SQL queries from a mapping."""
        metadata = self.parse_mapping(mapping_name)
        results = []
        rule_counter = 1

        for t in metadata.transformations:
            if t.type == "Source Qualifier":
                results.append({
                    "rule_id": f"R{rule_counter:03d}",
                    "transformation_name": t.name,
                    "type": t.type,
                    "query": t.sql_query or "[No override SQL - using default SELECT]",
                    "join_condition": t.join_condition
                })
                rule_counter += 1

        return results
