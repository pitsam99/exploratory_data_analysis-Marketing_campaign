"""
BDLM STTM Generator CLI
Usage:
  python -m bldmsttmgen generate --xml <XML> --mapping <NAME> [options]
  python -m bldmsttmgen batch --input <DIR> [options]
  python -m bldmsttmgen list --xml <XML>
  python -m bldmsttmgen validate --xml <XML>
"""

import argparse
import sys
import os

# Add src to path when running directly
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


def cmd_generate(args):
    from bldmsttmgen.generator import generate
    output = generate(
        xml_path=args.xml,
        mapping_name=args.mapping,
        out_dir=args.out_dir,
        mapplet_dir=args.mapplet_dir,
        mapplet_xmls=args.mapplet_xml or [],
        xlsx_only=args.xlsx_only
    )
    print(f"\nOutput: {output}")


def cmd_batch(args):
    from bldmsttmgen.batch import batch_generate
    results = batch_generate(
        input_dir=args.input,
        pattern=args.pattern,
        out_dir=args.out_dir,
        mapplet_dir=args.mapplet_dir,
        workers=args.workers,
        xlsx_only=args.xlsx_only
    )
    print(f"\nProcessed {len(results)} mappings")


def cmd_list(args):
    """List all mappings in an XML file."""
    from bldmsttmgen.parser import InformaticaXMLParser
    try:
        parser = InformaticaXMLParser(args.xml)
        mappings = parser.list_mappings()
        if mappings:
            print(f"\nMappings found in {args.xml}:")
            for i, m in enumerate(mappings, 1):
                print(f"  {i:2d}. {m}")
            print(f"\nTotal: {len(mappings)} mapping(s)")
        else:
            print(f"No mappings found in {args.xml}")
    except Exception as e:
        print(f"ERROR: {e}")
        sys.exit(1)


def cmd_validate(args):
    """Validate an XML file is a valid Informatica export."""
    from bldmsttmgen.parser import InformaticaXMLParser
    print(f"\nValidating: {args.xml}")
    try:
        parser = InformaticaXMLParser(args.xml)
        mappings = parser.list_mappings()
        print(f"✓ Valid Informatica PowerCenter export")
        print(f"✓ Found {len(mappings)} mapping(s)")
        print(f"✓ Found {len(parser.mapplet_registry)} mapplet(s) in registry")

        if args.mapplet_dir:
            print(f"✓ Mapplet directory: {args.mapplet_dir}")
            if not os.path.isdir(args.mapplet_dir):
                print(f"⚠ WARNING: Mapplet directory does not exist")

        print("\nAll checks passed ✓")
    except FileNotFoundError as e:
        print(f"✗ File not found: {e}")
        sys.exit(1)
    except ValueError as e:
        print(f"✗ Invalid XML: {e}")
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(
        prog="bldmsttmgen",
        description="BDLM STTM Generator — Informatica PowerCenter XML → STTM XLSX",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Generate single mapping
  python -m bldmsttmgen generate \\
    --xml input/samples/m_TMP_to_SHD.XML \\
    --mapping m_TMP_to_SHD \\
    --xlsx-only

  # Generate with mapplets
  python -m bldmsttmgen generate \\
    --xml input/samples/m_TMP_to_SHD.XML \\
    --mapping m_TMP_to_SHD \\
    --mapplet-dir input/mapplets/ \\
    --xlsx-only

  # Batch generate all XMLs
  python -m bldmsttmgen batch \\
    --input input/samples/ \\
    --pattern *.XML \\
    --workers 4 \\
    --xlsx-only

  # List mappings in XML
  python -m bldmsttmgen list --xml input/samples/m_TMP_to_SHD.XML

  # Validate XML
  python -m bldmsttmgen validate --xml input/samples/m_TMP_to_SHD.XML
        """
    )

    subparsers = parser.add_subparsers(dest="command", help="Command")
    subparsers.required = True

    # ── generate ──────────────────────────────────────────────
    gen_p = subparsers.add_parser("generate", help="Generate STTM for a single mapping")
    gen_p.add_argument("--xml",         required=True,  help="Path to Informatica XML export")
    gen_p.add_argument("--mapping",     required=True,  help="Mapping name to process")
    gen_p.add_argument("--out-dir",     default="output/bldmsttm", help="Output directory")
    gen_p.add_argument("--mapplet-dir", default=None,   help="Directory containing mapplet XMLs")
    gen_p.add_argument("--mapplet-xml", action="append", help="Individual mapplet XML (repeatable)")
    gen_p.add_argument("--xlsx-only",   action="store_true", default=True, help="Output XLSX only")
    gen_p.set_defaults(func=cmd_generate)

    # ── batch ─────────────────────────────────────────────────
    bat_p = subparsers.add_parser("batch", help="Batch generate STTM for multiple XMLs")
    bat_p.add_argument("--input",       required=True,  help="Input directory with XML files")
    bat_p.add_argument("--pattern",     default="*.XML", help="File pattern (default: *.XML)")
    bat_p.add_argument("--out-dir",     default="output/bldmsttm", help="Output directory")
    bat_p.add_argument("--mapplet-dir", default=None,   help="Directory containing mapplet XMLs")
    bat_p.add_argument("--workers",     type=int, default=4, help="Parallel workers (default: 4)")
    bat_p.add_argument("--xlsx-only",   action="store_true", default=True)
    bat_p.set_defaults(func=cmd_batch)

    # ── list ──────────────────────────────────────────────────
    lst_p = subparsers.add_parser("list", help="List all mappings in an XML file")
    lst_p.add_argument("--xml", required=True, help="Path to Informatica XML export")
    lst_p.set_defaults(func=cmd_list)

    # ── validate ──────────────────────────────────────────────
    val_p = subparsers.add_parser("validate", help="Validate an XML file")
    val_p.add_argument("--xml",         required=True, help="Path to Informatica XML export")
    val_p.add_argument("--mapplet-dir", default=None,  help="Directory to validate mapplets")
    val_p.set_defaults(func=cmd_validate)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
