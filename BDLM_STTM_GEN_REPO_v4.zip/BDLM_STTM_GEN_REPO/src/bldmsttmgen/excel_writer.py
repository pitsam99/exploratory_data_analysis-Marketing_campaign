"""
STTM Excel Writer
Generates professional XLSX output with 7 worksheets.
Dark green headers, frozen rows, auto-sized columns, borders.
"""

import openpyxl
from openpyxl.styles import (
    PatternFill, Font, Alignment, Border, Side
)
from openpyxl.utils import get_column_letter
from typing import List, Dict, Any
import os


# ── Design constants ──────────────────────────────────────────
HEADER_BG    = "1F5C2E"   # Dark green
HEADER_FG    = "FFFFFF"   # White text
ALT_ROW_BG   = "EAF4EB"   # Light green alternate rows
BORDER_COLOR = "A0C4A8"


def _make_border():
    side = Side(style="thin", color=BORDER_COLOR)
    return Border(left=side, right=side, top=side, bottom=side)


def _make_header_style():
    return {
        "fill": PatternFill("solid", fgColor=HEADER_BG),
        "font": Font(bold=True, color=HEADER_FG, name="Calibri", size=10),
        "alignment": Alignment(horizontal="center", vertical="center", wrap_text=True),
        "border": _make_border()
    }


def _make_cell_style(alternate: bool = False):
    bg = ALT_ROW_BG if alternate else "FFFFFF"
    return {
        "fill": PatternFill("solid", fgColor=bg),
        "font": Font(name="Calibri", size=9),
        "alignment": Alignment(vertical="top", wrap_text=True),
        "border": _make_border()
    }


def _apply_style(cell, style: dict):
    for attr, val in style.items():
        setattr(cell, attr, val)


def _write_sheet(ws, headers: List[str], rows: List[List[Any]],
                 freeze: bool = True):
    """Write headers + rows to a worksheet with formatting."""
    header_style = _make_header_style()

    # Write headers
    for col, h in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=h)
        _apply_style(cell, header_style)

    # Freeze top row
    if freeze:
        ws.freeze_panes = "A2"

    # Write data rows
    for row_idx, row in enumerate(rows, 2):
        alt = row_idx % 2 == 0
        cell_style = _make_cell_style(alt)
        for col, val in enumerate(row, 1):
            cell = ws.cell(row=row_idx, column=col, value=str(val) if val is not None else "")
            _apply_style(cell, cell_style)

    # Auto-size columns (cap at 60)
    for col in range(1, len(headers) + 1):
        max_len = len(headers[col - 1])
        for row in ws.iter_rows(min_row=2, min_col=col, max_col=col):
            for cell in row:
                if cell.value:
                    max_len = max(max_len, min(len(str(cell.value)), 60))
        ws.column_dimensions[get_column_letter(col)].width = max_len + 4

    # Row height for header
    ws.row_dimensions[1].height = 30


class STTMExcelWriter:
    """
    Generates STTM_<TARGET_TABLE>.xlsx with 7 professional worksheets.
    """

    def __init__(self, output_path: str):
        self.output_path = output_path
        self.wb = openpyxl.Workbook()
        self.wb.remove(self.wb.active)  # Remove default sheet

    def write_mapping_overview(self, data: Dict):
        """Sheet 1: Mapping Overview"""
        ws = self.wb.create_sheet("Mapping Overview")
        headers = [
            "Property", "Value"
        ]
        rows = [
            ["Mapping Name",       data.get("mapping_name", "")],
            ["Folder",             data.get("folder", "")],
            ["Description",        data.get("description", "")],
            ["Source Tables",      data.get("sources", "")],
            ["Target Tables",      data.get("targets", "")],
            ["Mapplets Used",      data.get("mapplets", "")],
            ["Transformations",    data.get("transformations", "")],
            ["Parameters",         data.get("parameters", "")],
            ["Data Flow",          data.get("data_flow", "")],
            ["Business Rules",     data.get("business_rules", "")],
            ["Source Qualifier SQL", data.get("sq_sql", "")],
        ]
        _write_sheet(ws, headers, rows)

    def write_sttm_mapping_table(self, rows: List[Dict]):
        """Sheet 2: STTM Mapping Table"""
        ws = self.wb.create_sheet("STTM Mapping Table")
        headers = [
            "Target Schema", "Target Table", "Target Column",
            "Target Data Type", "Target Precision", "Target Scale",
            "Source Qualifier SQL", "Straight Move / Calculated",
            "Technical Logic", "Lookup SQL Transformation",
            "Lookup Table", "Lookup Column",
            "Source Schema", "Source Table", "Source Column",
            "Source Data Type", "Source Precision", "Source Scale",
            "Notes"
        ]
        data_rows = [
            [
                r.get("target_schema", ""), r.get("target_table", ""),
                r.get("target_column", ""), r.get("target_datatype", ""),
                r.get("target_precision", ""), r.get("target_scale", ""),
                r.get("sq_sql", ""), r.get("straight_move", ""),
                r.get("technical_logic", ""), r.get("lookup_sql", ""),
                r.get("lookup_table", ""), r.get("lookup_column", ""),
                r.get("source_schema", ""), r.get("source_table", ""),
                r.get("source_column", ""), r.get("source_datatype", ""),
                r.get("source_precision", ""), r.get("source_scale", ""),
                r.get("notes", "")
            ]
            for r in rows
        ]
        _write_sheet(ws, headers, data_rows)

    def write_sql_query(self, rows: List[Dict]):
        """Sheet 3: SQL Query"""
        ws = self.wb.create_sheet("SQL Query")
        headers = ["Rule ID", "Transformation Name", "Type", "Query"]
        data_rows = [
            [r.get("rule_id", ""), r.get("transformation_name", ""),
             r.get("type", ""), r.get("query", "")]
            for r in rows
        ]
        _write_sheet(ws, headers, data_rows)

    def write_joins(self, rows: List[Dict]):
        """Sheet 4: Joins"""
        ws = self.wb.create_sheet("Joins")
        headers = [
            "Join ID", "Join Type", "Left Table", "Right Table",
            "Join Condition", "Cardinality", "Filter Condition", "Notes"
        ]
        data_rows = [
            [
                r.get("join_id", ""), r.get("join_type", ""),
                r.get("left_table", ""), r.get("right_table", ""),
                r.get("join_condition", ""), r.get("cardinality", ""),
                r.get("filter_condition", ""), r.get("notes", "")
            ]
            for r in rows
        ]
        _write_sheet(ws, headers, data_rows)

    def write_rules(self, rows: List[Dict]):
        """Sheet 5: Rules"""
        ws = self.wb.create_sheet("Rules")
        headers = [
            "Rule ID", "Rule Name", "Rule Description",
            "Applicable To", "Business Context",
            "Technical Implementation", "Notes"
        ]
        data_rows = [
            [
                r.get("rule_id", ""), r.get("rule_name", ""),
                r.get("rule_description", ""), r.get("applicable_to", ""),
                r.get("business_context", ""),
                r.get("technical_implementation", ""), r.get("notes", "")
            ]
            for r in rows
        ]
        _write_sheet(ws, headers, data_rows)

    def write_field_lineage(self, rows: List[Dict]):
        """Sheet 6: Field Lineage"""
        ws = self.wb.create_sheet("Field Lineage")
        headers = [
            "Target Table", "Target Column",
            "SQ Column Origin (table.column)",
            "Expression Transformations",
            "Lookup Transformations",
            "Final Source Table", "Final Source Column",
            "Lineage Notes"
        ]
        data_rows = [
            [
                r.get("target_table", ""), r.get("target_column", ""),
                r.get("sq_column_origin", ""),
                r.get("expression_transformations", ""),
                r.get("lookup_transformations", ""),
                r.get("final_source_table", ""),
                r.get("final_source_column", ""),
                r.get("lineage_notes", "")
            ]
            for r in rows
        ]
        _write_sheet(ws, headers, data_rows)

    def write_mapplet_dependencies(self, rows: List[Dict]):
        """Sheet 7: Mapplet Dependencies"""
        ws = self.wb.create_sheet("Mapplet Dependencies")
        headers = [
            "Mapplet Name", "Resolution Status",
            "Input Ports", "Output Ports",
            "Internal Logic Summary", "Dependency Notes"
        ]
        data_rows = [
            [
                r.get("mapplet_name", ""), r.get("resolution_status", ""),
                r.get("input_ports", ""), r.get("output_ports", ""),
                r.get("internal_logic", ""), r.get("notes", "")
            ]
            for r in rows
        ]
        _write_sheet(ws, headers, data_rows)

    def write_filter_conditions(self, rows: List[Dict]):
        """Sheet: Filter Conditions"""
        ws = self.wb.create_sheet("Filter Conditions")
        headers = ["Filter ID", "Transformation", "Condition",
                   "Effect", "Parameters Used", "Notes"]
        _write_sheet(ws, headers, [
            [r.get("filter_id",""), r.get("transformation",""), r.get("condition",""),
             r.get("effect",""), r.get("parameters_used",""), r.get("notes","")]
            for r in rows
        ])

    def write_router_groups(self, rows: List[Dict]):
        """Sheet: Router Groups"""
        ws = self.wb.create_sheet("Router Groups")
        headers = ["Router Name", "Group Name", "Condition",
                   "Is Default", "Routes To", "Notes"]
        _write_sheet(ws, headers, [
            [r.get("router_name",""), r.get("group_name",""), r.get("condition",""),
             r.get("is_default",""), r.get("routes_to",""), r.get("notes","")]
            for r in rows
        ])

    def write_aggregations(self, rows: List[Dict]):
        """Sheet: Aggregations"""
        ws = self.wb.create_sheet("Aggregations")
        headers = ["Transformation", "Output Port", "Port Type",
                   "Expression", "Aggregate Filter", "Group By Columns", "Notes"]
        _write_sheet(ws, headers, [
            [r.get("transformation",""), r.get("output_port",""), r.get("port_type",""),
             r.get("expression",""), r.get("aggregate_filter",""),
             r.get("group_by_columns",""), r.get("notes","")]
            for r in rows
        ])

    def write_update_strategies(self, rows: List[Dict]):
        """Sheet: Update Strategies"""
        ws = self.wb.create_sheet("Update Strategies")
        headers = ["Strategy ID", "Transformation", "Expression",
                   "Meaning", "Target", "Notes"]
        _write_sheet(ws, headers, [
            [r.get("strategy_id",""), r.get("transformation",""), r.get("expression",""),
             r.get("meaning",""), r.get("target",""), r.get("notes","")]
            for r in rows
        ])

    def write_parameters(self, rows: List[Dict]):
        """Sheet: Parameters & Variables"""
        ws = self.wb.create_sheet("Parameters & Variables")
        headers = ["Parameter Name", "Type", "Used In", "Notes"]
        _write_sheet(ws, headers, [
            [r.get("parameter_name",""), r.get("type",""),
             r.get("used_in",""), r.get("notes","")]
            for r in rows
        ])

    def write_unconnected_ports(self, rows: List[Dict]):
        """Sheet: Unconnected Ports"""
        ws = self.wb.create_sheet("Unconnected Ports")
        headers = ["Transformation", "Port Name", "Port Type", "Issue", "Risk"]
        # Colour HIGH risk rows red
        _write_sheet(ws, headers, [
            [r.get("transformation",""), r.get("port_name",""), r.get("port_type",""),
             r.get("issue",""), r.get("risk","")]
            for r in rows
        ])

    def save(self) -> str:
        """Save workbook to output path."""
        os.makedirs(os.path.dirname(self.output_path), exist_ok=True)
        self.wb.save(self.output_path)
        print(f"[OK] Saved: {self.output_path}")
        return self.output_path
