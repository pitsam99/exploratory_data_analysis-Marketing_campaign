"""
STTM Generator - Core generation logic
Orchestrates parsing → analysis → Excel writing
"""

import os
import re
from typing import List, Optional, Dict
from .parser import InformaticaXMLParser, MappingMetadata, Transformation
from .excel_writer import STTMExcelWriter


def generate(
    xml_path: str,
    mapping_name: str,
    out_dir: str = "output/bldmsttm",
    mapplet_dir: Optional[str] = None,
    mapplet_xmls: Optional[List[str]] = None,
    xlsx_only: bool = True
) -> str:
    """
    Generate STTM documentation for a single mapping.

    Args:
        xml_path:      Path to Informatica XML export
        mapping_name:  Name of the mapping to process
        out_dir:       Output directory
        mapplet_dir:   Directory containing mapplet XMLs
        mapplet_xmls:  List of individual mapplet XML paths
        xlsx_only:     Output XLSX only (no CSVs)

    Returns:
        Path to generated XLSX file
    """
    print(f"\n{'='*60}")
    print(f"  BDLM STTM Generator v1.0")
    print(f"{'='*60}")
    print(f"  XML:     {xml_path}")
    print(f"  Mapping: {mapping_name}")
    print(f"  Out Dir: {out_dir}")
    if mapplet_dir:
        print(f"  Mapplets:{mapplet_dir}")
    print(f"{'='*60}\n")

    # ── Step 1: Parse ─────────────────────────────────────────
    print("[1/4] Parsing XML...")
    parser = InformaticaXMLParser(
        xml_path=xml_path,
        mapplet_dir=mapplet_dir,
        mapplet_xmls=mapplet_xmls
    )
    metadata = parser.parse_mapping(mapping_name)
    print(f"      Found {len(metadata.transformations)} transformations")
    print(f"      Found {len(metadata.connectors)} connectors")
    print(f"      Found {len(metadata.mapplets)} mapplet references")

    # ── Step 2: Analyze ───────────────────────────────────────
    print("[2/4] Analyzing mappings and lineage...")
    analyzer = MappingAnalyzer(metadata, parser)
    analysis = analyzer.analyze()

    # ── Step 3: Determine output filename ─────────────────────
    target_table = _extract_target_table(metadata)
    output_path = os.path.join(out_dir, f"STTM_{target_table}.xlsx")

    # ── Step 4: Write Excel ───────────────────────────────────
    print("[3/4] Writing Excel output...")
    writer = STTMExcelWriter(output_path)
    writer.write_mapping_overview(analysis["overview"])
    writer.write_sttm_mapping_table(analysis["mapping_table"])
    writer.write_sql_query(analysis["sql_queries"])
    writer.write_joins(analysis["joins"])
    writer.write_rules(analysis["rules"])
    writer.write_field_lineage(analysis["field_lineage"])
    writer.write_mapplet_dependencies(analysis["mapplet_dependencies"])
    # New sheets
    if analysis["filter_conditions"]:
        writer.write_filter_conditions(analysis["filter_conditions"])
    if analysis["router_groups"]:
        writer.write_router_groups(analysis["router_groups"])
    if analysis["aggregations"]:
        writer.write_aggregations(analysis["aggregations"])
    if analysis["update_strategies"]:
        writer.write_update_strategies(analysis["update_strategies"])
    if analysis["parameters"]:
        writer.write_parameters(analysis["parameters"])
    if analysis["unconnected_ports"]:
        writer.write_unconnected_ports(analysis["unconnected_ports"])

    print("[4/4] Saving...")
    path = writer.save()

    print(f"\n✓ Generation complete!")
    print(f"  Output: {path}")

    if analysis.get("warnings"):
        print(f"\n⚠ Warnings ({len(analysis['warnings'])}):")
        for w in analysis["warnings"]:
            print(f"  - {w}")

    return path


def _extract_target_table(metadata: MappingMetadata) -> str:
    """Extract target table name from mapping metadata."""
    for t in metadata.transformations:
        if t.type in ("Target Definition", "Normalizer"):
            return t.name.upper().replace(" ", "_")

    # Fallback: derive from mapping name
    name = metadata.name
    # Remove common prefixes like m_, mplt_
    name = re.sub(r'^m_', '', name, flags=re.IGNORECASE)
    return name.upper()


class MappingAnalyzer:
    """Analyzes parsed mapping metadata and builds STTM data structures."""

    def __init__(self, metadata: MappingMetadata, parser: InformaticaXMLParser):
        self.metadata = metadata
        self.parser = parser
        self.warnings: List[str] = []

    def analyze(self) -> Dict:
        return {
            "overview":              self._build_overview(),
            "mapping_table":         self._build_mapping_table(),
            "sql_queries":           self._build_sql_queries(),
            "joins":                 self._build_joins(),
            "rules":                 self._build_rules(),
            "field_lineage":         self._build_field_lineage(),
            "mapplet_dependencies":  self._build_mapplet_dependencies(),
            "filter_conditions":     self._build_filter_conditions(),
            "router_groups":         self._build_router_groups(),
            "aggregations":          self._build_aggregations(),
            "update_strategies":     self._build_update_strategies(),
            "parameters":            self._build_parameters(),
            "unconnected_ports":     self._build_unconnected_ports(),
            "warnings":              self.warnings
        }

    def _build_overview(self) -> Dict:
        m = self.metadata
        sources  = [t.name for t in m.transformations if "Source" in t.type and t.type != "Source Qualifier"]
        targets  = [t.name for t in m.transformations if "Target" in t.type]
        sq_sqls  = [t.sql_query for t in m.transformations if t.type == "Source Qualifier" and t.sql_query]
        filters  = [t for t in m.transformations if t.type == "Filter"]
        routers  = [t for t in m.transformations if t.type == "Router"]
        aggs     = [t for t in m.transformations if t.type == "Aggregator"]
        updates  = [t for t in m.transformations if t.type == "Update Strategy"]
        unions   = [t for t in m.transformations if t.type == "Union"]
        joiners  = [t for t in m.transformations if t.type == "Joiner"]

        # Separate session params from mapping variables
        session_params = {k: v for k, v in m.parameters.items() if k.startswith("$$")}
        mapping_vars   = {k: v for k, v in m.parameters.items() if k.startswith("$") and not k.startswith("$$")}

        notes = []
        if m.has_multiple_targets:
            notes.append(f"⚠ MULTI-TARGET mapping: {', '.join(targets)}")
        if unions:
            notes.append(f"⚠ UNION transformation present — {len(unions)} union(s), each branch documented separately")
        if updates:
            notes.append(f"⚠ UPDATE STRATEGY present — {', '.join(t.update_strategy_expr for t in updates)}")

        return {
            "mapping_name":      m.name,
            "folder":            m.folder,
            "description":       m.description or "No description provided",
            "sources":           ", ".join(sources) or "See SQL",
            "targets":           ", ".join(targets) or "See XML",
            "multiple_targets":  "YES" if m.has_multiple_targets else "NO",
            "target_load_order": " → ".join(m.target_load_order) if m.has_multiple_targets else "N/A",
            "mapplets":          ", ".join(m.mapplets) or "None",
            "transformations":   self._build_data_flow_description(),
            "filters":           ", ".join(f.name for f in filters) or "None",
            "routers":           ", ".join(r.name for r in routers) or "None",
            "aggregators":       ", ".join(a.name for a in aggs) or "None",
            "update_strategies": ", ".join(u.name for u in updates) or "None",
            "union_transformations": ", ".join(u.name for u in unions) or "None",
            "joiner_transformations": ", ".join(j.name for j in joiners) or "None",
            "session_parameters": ", ".join(session_params.keys()) or "None",
            "mapping_variables":  ", ".join(mapping_vars.keys()) or "None",
            "data_flow":         self._build_data_flow_description(),
            "business_rules":    "See Rules worksheet",
            "sq_sql":            "\n\n".join(sq_sqls) or "[No SQL override found]",
            "notes":             " | ".join(notes) if notes else ""
        }

    def _build_data_flow_description(self) -> str:
        ORDER = [
            ("Source Definition", "Source"),
            ("Source Qualifier",  "SQ (SQL)"),
            ("Joiner",            "Joiner"),
            ("Filter",            "Filter"),
            ("Expression",        "Expression"),
            ("Lookup Procedure",  "Lookup"),
            ("Aggregator",        "Aggregator"),
            ("Rank",              "Rank"),
            ("Router",            "Router"),
            ("Union",             "Union"),
            ("Sorter",            "Sorter"),
            ("Normalizer",        "Normalizer"),
            ("Sequence Generator","Sequence"),
            ("Update Strategy",   "UpdateStrategy"),
            ("Target Definition", "Target"),
        ]
        seen_types = {t.type for t in self.metadata.transformations}
        parts = [label for type_key, label in ORDER
                 if any(type_key in s for s in seen_types)]
        return " → ".join(parts) if parts else f"{len(self.metadata.transformations)} transformations"

    def _build_mapping_table(self) -> List[Dict]:
        """Build field-level source-to-target mapping rows."""
        rows = []
        m = self.metadata

        # Find target transformation
        targets = [t for t in m.transformations if "Target" in t.type]
        if not targets:
            self.warnings.append("No Target transformation found in mapping")
            return rows

        target = targets[0]
        # Build connector lookup: to_field → from details
        conn_map = {}
        for c in m.connectors:
            if c.to_transformation == target.name:
                conn_map[c.to_field] = c

        for port in target.ports:
            if port.porttype in ("INPUT", ""):
                conn = conn_map.get(port.name)
                source_info = self._trace_lineage(conn) if conn else {}

                rows.append({
                    "target_schema":    self._extract_schema(target.name),
                    "target_table":     target.name,
                    "target_column":    port.name,
                    "target_datatype":  port.datatype,
                    "target_precision": port.precision,
                    "target_scale":     port.scale,
                    "sq_sql":           source_info.get("sq_sql", ""),
                    "straight_move":    source_info.get("straight_move", "Calculated"),
                    "technical_logic":  source_info.get("technical_logic", ""),
                    "lookup_sql":       source_info.get("lookup_sql", ""),
                    "lookup_table":     source_info.get("lookup_table", ""),
                    "lookup_column":    source_info.get("lookup_column", ""),
                    "source_schema":    source_info.get("source_schema", ""),
                    "source_table":     source_info.get("source_table", ""),
                    "source_column":    source_info.get("source_column", ""),
                    "source_datatype":  source_info.get("source_datatype", ""),
                    "source_precision": source_info.get("source_precision", ""),
                    "source_scale":     source_info.get("source_scale", ""),
                    "notes":            source_info.get("notes", "")
                })

        return rows

    def _trace_lineage(self, connector, depth: int = 0) -> Dict:
        """Recursively trace lineage through connectors."""
        if depth > 10:
            return {"notes": "**UNRESOLVED: max recursion depth reached**"}

        m = self.metadata
        from_trans_name = connector.from_transformation
        from_field = connector.from_field

        # Find the from-transformation
        from_trans = next(
            (t for t in m.transformations if t.name == from_trans_name), None
        )
        if not from_trans:
            return {"notes": f"**UNRESOLVED: transformation '{from_trans_name}' not found**"}

        # Source Qualifier → direct lineage
        if from_trans.type == "Source Qualifier":
            return {
                "sq_sql": from_trans.sql_query or "[default SELECT]",
                "source_column": from_field,
                "straight_move": "Straight Move",
                "technical_logic": f"{from_trans_name}.{from_field}"
            }

        # Expression → resolve expression
        if from_trans.type == "Expression":
            port = next((p for p in from_trans.ports if p.name == from_field), None)
            if port:
                if port.porttype == "LOCAL VARIABLE":
                    # Recurse: find upstream connector for this variable
                    up_conn = next(
                        (c for c in m.connectors
                         if c.to_transformation == from_trans_name
                         and c.to_field == from_field), None
                    )
                    if up_conn:
                        result = self._trace_lineage(up_conn, depth + 1)
                        result["technical_logic"] = port.expression
                        return result

                is_const = self._is_constant(port.expression)
                return {
                    "technical_logic": port.expression,
                    "straight_move":   "Calculated",
                    "source_column":   f"CONST({port.expression})" if is_const else from_field,
                    "notes":           "CONST expression" if is_const else ""
                }

        # Lookup → document lookup
        if "Lookup" in from_trans.type:
            return {
                "lookup_sql":    from_trans.lookup_condition,
                "lookup_table":  from_trans.lookup_table,
                "lookup_column": from_field,
                "straight_move": "Calculated",
                "technical_logic": f"Lookup: {from_trans.lookup_table}.{from_field}"
            }

        # Mapplet → resolve through registry
        if from_trans.type == "Mapplet" or "MAPPLET" in from_trans.type.upper():
            mplt_def = self.parser.resolve_mapplet_lineage(from_trans_name)
            if mplt_def is None:
                self.warnings.append(
                    f"Mapplet '{from_trans_name}' definition not found. "
                    f"Pass --mapplet-dir to resolve."
                )
                return {
                    "notes": f"**UNRESOLVED: mapplet '{from_trans_name}' definition missing; "
                             f"cannot expand internals**",
                    "technical_logic": f"{from_trans_name}.{from_field}"
                }
            return {
                "technical_logic": f"Via mapplet {from_trans_name}.{from_field}",
                "notes": f"Mapplet resolved: {from_trans_name}"
            }

        # Default: trace upstream
        up_conn = next(
            (c for c in m.connectors
             if c.to_transformation == from_trans_name
             and c.to_field == from_field), None
        )
        if up_conn:
            return self._trace_lineage(up_conn, depth + 1)

        return {
            "source_column": from_field,
            "technical_logic": f"{from_trans_name}.{from_field}",
            "straight_move": "Straight Move"
        }

    def _is_constant(self, expression: str) -> bool:
        """Check if expression is a constant/built-in."""
        if not expression:
            return False
        constants = ["SYSDATE", "NULL", "TRUE", "FALSE"]
        expr = expression.strip().upper()
        if expr in constants:
            return True
        # Numeric literal
        try:
            float(expr)
            return True
        except ValueError:
            pass
        # String literal
        if (expr.startswith("'") and expr.endswith("'")) or \
           (expr.startswith('"') and expr.endswith('"')):
            return True
        return False

    def _build_sql_queries(self) -> List[Dict]:
        rows = []
        counter = 1
        for t in self.metadata.transformations:
            if t.type == "Source Qualifier":
                rows.append({
                    "rule_id": f"R{counter:03d}",
                    "transformation_name": t.name,
                    "type": t.type,
                    "query": t.sql_query or "[No SQL override - using default SELECT *]"
                })
                counter += 1
        return rows

    def _build_joins(self) -> List[Dict]:
        rows = []
        counter = 1
        for t in self.metadata.transformations:
            # SQ join condition
            if t.type == "Source Qualifier" and t.join_condition:
                for jp in self._parse_join_condition(t.join_condition):
                    rows.append({
                        "join_id":         f"J{counter:03d}",
                        "join_source":     "Source Qualifier",
                        "transformation":  t.name,
                        "join_type":       jp.get("type", "INNER"),
                        "left_table":      jp.get("left_table", ""),
                        "right_table":     jp.get("right_table", ""),
                        "join_condition":  jp.get("condition", t.join_condition),
                        "cardinality":     "N:1",
                        "filter_condition": "",
                        "notes":           "Defined in Source Qualifier join condition"
                    })
                    counter += 1
            # Joiner transformation (active joins in mapping)
            elif t.type == "Joiner" and t.join_condition:
                join_type_map = {
                    "Normal":           "INNER JOIN",
                    "Master Outer":     "RIGHT OUTER JOIN",
                    "Detail Outer":     "LEFT OUTER JOIN",
                    "Full Outer":       "FULL OUTER JOIN",
                }
                rows.append({
                    "join_id":         f"J{counter:03d}",
                    "join_source":     "Joiner Transformation",
                    "transformation":  t.name,
                    "join_type":       join_type_map.get(t.join_type, t.join_type or "INNER JOIN"),
                    "left_table":      "Detail pipeline",
                    "right_table":     "Master pipeline",
                    "join_condition":  t.join_condition,
                    "cardinality":     "N:1",
                    "filter_condition": "",
                    "notes":           f"Joiner type: {t.join_type}"
                })
                counter += 1
        return rows

    def _parse_join_condition(self, condition: str) -> List[Dict]:
        """Simple join condition parser."""
        joins = []
        lines = condition.split("\n")
        for line in lines:
            line = line.strip()
            if not line:
                continue
            join_type = "INNER"
            if "LEFT" in line.upper():
                join_type = "LEFT OUTER"
            elif "RIGHT" in line.upper():
                join_type = "RIGHT OUTER"
            joins.append({
                "type": join_type,
                "condition": line,
                "left_table": "",
                "right_table": ""
            })
        return joins if joins else [{"type": "INNER", "condition": condition}]

    def _build_rules(self) -> List[Dict]:
        rows = []
        counter = 1
        for t in self.metadata.transformations:
            if t.type == "Source Qualifier" and t.sql_query:
                rows.append({
                    "rule_id": f"R{counter:03d}",
                    "rule_name": f"Source Qualifier SQL - {t.name}",
                    "rule_description": "Source Qualifier SQL override defines actual data extraction logic",
                    "applicable_to": t.name,
                    "business_context": "Defines the exact rows and columns extracted from source system",
                    "technical_implementation": t.sql_query,
                    "notes": ""
                })
                counter += 1

            # Expression rules
            if t.type == "Expression":
                for port in t.ports:
                    if port.porttype == "OUTPUT" and port.expression:
                        rows.append({
                            "rule_id": f"R{counter:03d}",
                            "rule_name": f"Expression - {port.name}",
                            "rule_description": port.description or f"Expression transformation for {port.name}",
                            "applicable_to": f"{t.name}.{port.name}",
                            "business_context": f"Computes {port.name} value",
                            "technical_implementation": port.expression,
                            "notes": "CONST expression" if self._is_constant(port.expression) else ""
                        })
                        counter += 1

        return rows

    def _build_field_lineage(self) -> List[Dict]:
        """Build full field lineage tracing."""
        rows = []
        m = self.metadata
        targets = [t for t in m.transformations if "Target" in t.type]
        if not targets:
            return rows

        target = targets[0]
        conn_map = {c.to_field: c for c in m.connectors if c.to_transformation == target.name}

        for port in target.ports:
            if port.porttype in ("INPUT", ""):
                conn = conn_map.get(port.name)
                lineage = self._trace_lineage(conn) if conn else {}

                rows.append({
                    "target_table":              target.name,
                    "target_column":             port.name,
                    "sq_column_origin":          lineage.get("source_column", ""),
                    "expression_transformations": lineage.get("technical_logic", ""),
                    "lookup_transformations":    lineage.get("lookup_sql", ""),
                    "final_source_table":        lineage.get("source_table", ""),
                    "final_source_column":       lineage.get("source_column", ""),
                    "lineage_notes":             lineage.get("notes", "")
                })

        return rows

    def _build_mapplet_dependencies(self) -> List[Dict]:
        rows = []
        for mplt_name in self.metadata.mapplets:
            mplt_def = self.parser.resolve_mapplet_lineage(mplt_name)
            if mplt_def is not None:
                input_ports = [
                    p.get("NAME", "") for p in mplt_def.findall(".//TRANSFORMFIELD")
                    if p.get("PORTTYPE") == "INPUT"
                ]
                output_ports = [
                    p.get("NAME", "") for p in mplt_def.findall(".//TRANSFORMFIELD")
                    if p.get("PORTTYPE") == "OUTPUT"
                ]
                rows.append({
                    "mapplet_name":      mplt_name,
                    "resolution_status": "RESOLVED",
                    "input_ports":       ", ".join(input_ports),
                    "output_ports":      ", ".join(output_ports),
                    "internal_logic":    "See mapplet XML",
                    "notes":             ""
                })
            else:
                rows.append({
                    "mapplet_name":      mplt_name,
                    "resolution_status": "**UNRESOLVED - pass --mapplet-dir**",
                    "input_ports":       "",
                    "output_ports":      "",
                    "internal_logic":    "",
                    "notes":             "Mapplet definition not found in current XML or mapplet directory"
                })
        return rows

    def _build_filter_conditions(self) -> List[Dict]:
        """Document all Filter transformation conditions."""
        rows = []
        counter = 1
        for t in self.metadata.transformations:
            if t.type == "Filter" and t.filter_condition:
                rows.append({
                    "filter_id":       f"F{counter:03d}",
                    "transformation":  t.name,
                    "condition":       t.filter_condition,
                    "effect":          "Rows NOT matching condition are DROPPED",
                    "parameters_used": ", ".join(
                        p for p in self.metadata.parameters if p in t.filter_condition
                    ),
                    "notes":           ""
                })
                counter += 1
        return rows

    def _build_router_groups(self) -> List[Dict]:
        """Document Router transformation groups and their conditions."""
        rows = []
        for t in self.metadata.transformations:
            if t.type == "Router":
                if not t.router_groups:
                    self.warnings.append(
                        f"Router '{t.name}' has no groups defined in XML — "
                        f"check XML for GROUP elements"
                    )
                for grp in t.router_groups:
                    rows.append({
                        "router_name":   t.name,
                        "group_name":    grp.name,
                        "condition":     grp.condition,
                        "is_default":    "YES" if grp.name.upper() == "DEFAULT" else "NO",
                        "routes_to":     f"Downstream of {t.name}.{grp.name}",
                        "notes":         "Default group catches all unmatched rows" if grp.name.upper() == "DEFAULT" else ""
                    })
        return rows

    def _build_aggregations(self) -> List[Dict]:
        """Document Aggregator transformations — group-by ports and aggregate expressions."""
        rows = []
        for t in self.metadata.transformations:
            if t.type == "Aggregator":
                for port in t.ports:
                    if port.porttype == "OUTPUT":
                        is_groupby = port.name in t.group_by_ports
                        rows.append({
                            "transformation":    t.name,
                            "output_port":       port.name,
                            "port_type":         "GROUP BY" if is_groupby else "AGGREGATE",
                            "expression":        port.expression,
                            "aggregate_filter":  t.aggregate_filter or "None",
                            "group_by_columns":  ", ".join(t.group_by_ports) or "None",
                            "notes":             ""
                        })
        return rows

    def _build_update_strategies(self) -> List[Dict]:
        """Document Update Strategy transformation expressions."""
        rows = []
        counter = 1
        for t in self.metadata.transformations:
            if t.type == "Update Strategy":
                rows.append({
                    "strategy_id":   f"US{counter:03d}",
                    "transformation": t.name,
                    "expression":     t.update_strategy_expr or "[Default: DD_INSERT]",
                    "meaning":        self._decode_update_strategy(t.update_strategy_expr),
                    "target":         self._find_downstream_target(t.name),
                    "notes":          "Controls INSERT/UPDATE/DELETE/REJECT per row"
                })
                counter += 1
        return rows

    def _decode_update_strategy(self, expr: str) -> str:
        """Decode DD_ constants to human-readable meaning."""
        if not expr:
            return "DD_INSERT (default — insert all rows)"
        mapping = {
            "DD_INSERT":  "Insert all rows",
            "DD_UPDATE":  "Update existing rows",
            "DD_DELETE":  "Delete rows",
            "DD_REJECT":  "Reject rows",
        }
        for k, v in mapping.items():
            if k in expr:
                return v
        return f"Conditional: {expr}"

    def _find_downstream_target(self, trans_name: str) -> str:
        """Find target downstream of a given transformation."""
        visited = set()
        queue = [trans_name]
        while queue:
            current = queue.pop(0)
            if current in visited:
                continue
            visited.add(current)
            for c in self.metadata.connectors:
                if c.from_transformation == current:
                    trans = next(
                        (t for t in self.metadata.transformations
                         if t.name == c.to_transformation), None
                    )
                    if trans and "Target" in trans.type:
                        return trans.name
                    queue.append(c.to_transformation)
        return "Unknown"

    def _build_parameters(self) -> List[Dict]:
        """Document all session parameters and mapping variables."""
        rows = []
        for name, ptype in self.metadata.parameters.items():
            # Find where used
            used_in = []
            for t in self.metadata.transformations:
                for port in t.ports:
                    if name in port.expression:
                        used_in.append(f"{t.name}.{port.name}")
                if name in t.sql_query or name in t.filter_condition or name in t.lookup_condition:
                    used_in.append(t.name)

            rows.append({
                "parameter_name": name,
                "type":           ptype,
                "used_in":        ", ".join(dict.fromkeys(used_in)) or "See expressions",
                "notes":          "Must be set in session/workflow before run"
                                  if ptype == "Session parameter"
                                  else "Mapping variable — initialized in mapping"
            })
        return rows

    def _build_unconnected_ports(self) -> List[Dict]:
        """Identify unconnected INPUT/OUTPUT ports — data quality risk."""
        rows = []
        connected_inputs  = {(c.to_transformation, c.to_field) for c in self.metadata.connectors}
        connected_outputs = {(c.from_transformation, c.from_field) for c in self.metadata.connectors}

        for t in self.metadata.transformations:
            if "Target" in t.type:
                for port in t.ports:
                    if port.porttype == "INPUT":
                        if (t.name, port.name) not in connected_inputs:
                            rows.append({
                                "transformation": t.name,
                                "port_name":      port.name,
                                "port_type":      "TARGET INPUT",
                                "issue":          "UNCONNECTED — target column will receive NULLs",
                                "risk":           "HIGH" if "NOT NULL" in port.description.upper() else "MEDIUM"
                            })
            elif t.type not in ("Source Definition", "Source"):
                for port in t.ports:
                    if port.porttype == "OUTPUT":
                        if (t.name, port.name) not in connected_outputs:
                            rows.append({
                                "transformation": t.name,
                                "port_name":      port.name,
                                "port_type":      "OUTPUT",
                                "issue":          "UNCONNECTED OUTPUT — port computed but never used",
                                "risk":           "LOW"
                            })
        return rows

    def _extract_schema(self, table_name: str) -> str:
        """Extract schema from table name if schema.table format."""
        if "." in table_name:
            return table_name.split(".")[0]
        return ""
