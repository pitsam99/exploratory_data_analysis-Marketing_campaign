"""
Comprehensive tests: Lookup detail, port renaming, lineage tracing,
connector issues, multiple lookups, LOCAL VARIABLE resolution.
Run: pytest tests/test_lookup_lineage.py -v
"""

import pytest
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from bldmsttmgen.parser import InformaticaXMLParser, LookupDetail
from bldmsttmgen.generator import MappingAnalyzer


# ── XML Fixtures ──────────────────────────────────────────────

MULTI_LOOKUP_XML = """<?xml version="1.0" encoding="UTF-8"?>
<POWERMART>
  <REPOSITORY NAME="R">
    <FOLDER NAME="F">
      <MAPPING NAME="m_MULTI_LOOKUP">
        <!-- Source Qualifier with aliased SQL -->
        <TRANSFORMATION NAME="SQ_SRC" TYPE="Source Qualifier">
          <TABLEATTRIBUTE NAME="Sql Query"
            VALUE="SELECT A.BOOK_ID, A.CCY_CD, A.AMOUNT FROM BLDM_TMP.V_BOOK A WHERE A.STATUS = &apos;Y&apos;"/>
          <TRANSFORMFIELD NAME="BOOK_ID" DATATYPE="decimal"  PRECISION="18" SCALE="0" PORTTYPE="OUTPUT"/>
          <TRANSFORMFIELD NAME="CCY_CD"  DATATYPE="varchar"  PRECISION="3"  SCALE="0" PORTTYPE="OUTPUT"/>
          <TRANSFORMFIELD NAME="AMOUNT"  DATATYPE="decimal"  PRECISION="28" SCALE="8" PORTTYPE="OUTPUT"/>
        </TRANSFORMATION>

        <!-- Lookup 1: currency rates (connected, cached) -->
        <TRANSFORMATION NAME="LKP_FX_RATE" TYPE="Lookup Procedure">
          <TABLEATTRIBUTE NAME="Lookup table name"   VALUE="BLDM_REF.T_FX_RATES"/>
          <TABLEATTRIBUTE NAME="Lookup Condition"    VALUE="LKP_FX_RATE.CCY_CD = SQ_SRC.CCY_CD"/>
          <TABLEATTRIBUTE NAME="Lookup Condition Type"            VALUE="="/>
          <TABLEATTRIBUTE NAME="Lookup Caching Enabled"           VALUE="YES"/>
          <TABLEATTRIBUTE NAME="Lookup Policy on Multiple Match"  VALUE="Use first value"/>
          <TRANSFORMFIELD NAME="CCY_CD"      DATATYPE="varchar"  PRECISION="3"  SCALE="0" PORTTYPE="INPUT"/>
          <TRANSFORMFIELD NAME="RATE_TO_USD" DATATYPE="decimal"  PRECISION="18" SCALE="8" PORTTYPE="OUTPUT"/>
          <TRANSFORMFIELD NAME="RATE_DT"     DATATYPE="date/time" PRECISION="29" SCALE="9" PORTTYPE="OUTPUT"/>
        </TRANSFORMATION>

        <!-- Lookup 2: risk weights (connected, not cached, same schema different table) -->
        <TRANSFORMATION NAME="LKP_RISK_WEIGHT" TYPE="Lookup Procedure">
          <TABLEATTRIBUTE NAME="Lookup table name"   VALUE="BLDM_REF.T_RISK_WEIGHT"/>
          <TABLEATTRIBUTE NAME="Lookup Sql Override" VALUE="SELECT BOOK_TYPE_CD, RISK_PCT FROM BLDM_REF.T_RISK_WEIGHT WHERE ACTIVE_FLG = &apos;Y&apos;"/>
          <TABLEATTRIBUTE NAME="Lookup Condition Type"            VALUE="="/>
          <TABLEATTRIBUTE NAME="Lookup Caching Enabled"           VALUE="NO"/>
          <TABLEATTRIBUTE NAME="Lookup Policy on Multiple Match"  VALUE="Use last value"/>
          <TRANSFORMFIELD NAME="BOOK_ID_IN"  DATATYPE="decimal"  PRECISION="18" SCALE="0" PORTTYPE="INPUT"/>
          <TRANSFORMFIELD NAME="RISK_PCT"    DATATYPE="decimal"  PRECISION="10" SCALE="4" PORTTYPE="OUTPUT"/>
        </TRANSFORMATION>

        <!-- Lookup 3: UNCONNECTED — result never used -->
        <TRANSFORMATION NAME="LKP_UNCONNECTED" TYPE="Lookup Procedure">
          <TABLEATTRIBUTE NAME="Lookup table name" VALUE="BLDM_REF.T_UNUSED"/>
          <TABLEATTRIBUTE NAME="Lookup Caching Enabled" VALUE="NO"/>
          <TABLEATTRIBUTE NAME="Lookup Policy on Multiple Match" VALUE="Use first value"/>
          <TRANSFORMFIELD NAME="IN_ID"     DATATYPE="decimal" PRECISION="18" SCALE="0" PORTTYPE="INPUT"/>
          <TRANSFORMFIELD NAME="OUT_VALUE" DATATYPE="varchar" PRECISION="50" SCALE="0" PORTTYPE="OUTPUT"/>
        </TRANSFORMATION>

        <!-- Expression with LOCAL VARIABLE, renamed ports, multi-input expression -->
        <TRANSFORMATION NAME="EXP_CALC" TYPE="Expression">
          <TRANSFORMFIELD NAME="IN_BOOK_ID"    DATATYPE="decimal"  PRECISION="18" SCALE="0"  PORTTYPE="INPUT"        EXPRESSION=""/>
          <TRANSFORMFIELD NAME="IN_AMOUNT"     DATATYPE="decimal"  PRECISION="28" SCALE="8"  PORTTYPE="INPUT"        EXPRESSION=""/>
          <TRANSFORMFIELD NAME="IN_RATE"       DATATYPE="decimal"  PRECISION="18" SCALE="8"  PORTTYPE="INPUT"        EXPRESSION=""/>
          <TRANSFORMFIELD NAME="IN_RISK_PCT"   DATATYPE="decimal"  PRECISION="10" SCALE="4"  PORTTYPE="INPUT"        EXPRESSION=""/>
          <TRANSFORMFIELD NAME="V_AMT_USD"     DATATYPE="decimal"  PRECISION="28" SCALE="8"  PORTTYPE="LOCAL VARIABLE" EXPRESSION="IN_AMOUNT * IN_RATE"/>
          <TRANSFORMFIELD NAME="V_RISK_AMT"    DATATYPE="decimal"  PRECISION="28" SCALE="8"  PORTTYPE="LOCAL VARIABLE" EXPRESSION="V_AMT_USD * IN_RISK_PCT / 100"/>
          <TRANSFORMFIELD NAME="OUT_BOOK_ID"   DATATYPE="decimal"  PRECISION="18" SCALE="0"  PORTTYPE="OUTPUT"       EXPRESSION="IN_BOOK_ID"/>
          <TRANSFORMFIELD NAME="OUT_AMT_USD"   DATATYPE="decimal"  PRECISION="28" SCALE="8"  PORTTYPE="OUTPUT"       EXPRESSION="V_AMT_USD"/>
          <TRANSFORMFIELD NAME="OUT_RISK_AMT"  DATATYPE="decimal"  PRECISION="28" SCALE="8"  PORTTYPE="OUTPUT"       EXPRESSION="V_RISK_AMT"/>
          <TRANSFORMFIELD NAME="OUT_LOAD_DT"   DATATYPE="date/time" PRECISION="29" SCALE="9" PORTTYPE="OUTPUT"       EXPRESSION="SYSDATE"/>
        </TRANSFORMATION>

        <!-- Target -->
        <TRANSFORMATION NAME="TGT_BOOK_FACT" TYPE="Target Definition">
          <TRANSFORMFIELD NAME="BOOK_ID"   DATATYPE="decimal"  PRECISION="18" SCALE="0"  PORTTYPE="INPUT"/>
          <TRANSFORMFIELD NAME="AMT_USD"   DATATYPE="decimal"  PRECISION="28" SCALE="8"  PORTTYPE="INPUT"/>
          <TRANSFORMFIELD NAME="RISK_AMT"  DATATYPE="decimal"  PRECISION="28" SCALE="8"  PORTTYPE="INPUT"/>
          <TRANSFORMFIELD NAME="LOAD_DT"   DATATYPE="date/time" PRECISION="29" SCALE="9" PORTTYPE="INPUT"/>
        </TRANSFORMATION>

        <!-- SQ → LKP1 (lookup key) -->
        <CONNECTOR FROMINSTANCE="SQ_SRC"      FROMFIELD="CCY_CD"    TOINSTANCE="LKP_FX_RATE"    TOFIELD="CCY_CD"/>
        <!-- SQ → LKP2 (lookup key) -->
        <CONNECTOR FROMINSTANCE="SQ_SRC"      FROMFIELD="BOOK_ID"   TOINSTANCE="LKP_RISK_WEIGHT" TOFIELD="BOOK_ID_IN"/>
        <!-- SQ → LKP3 UNCONNECTED input (input port fed but output never used) -->
        <CONNECTOR FROMINSTANCE="SQ_SRC"      FROMFIELD="BOOK_ID"   TOINSTANCE="LKP_UNCONNECTED" TOFIELD="IN_ID"/>
        <!-- SQ → EXP -->
        <CONNECTOR FROMINSTANCE="SQ_SRC"      FROMFIELD="BOOK_ID"   TOINSTANCE="EXP_CALC"       TOFIELD="IN_BOOK_ID"/>
        <CONNECTOR FROMINSTANCE="SQ_SRC"      FROMFIELD="AMOUNT"    TOINSTANCE="EXP_CALC"       TOFIELD="IN_AMOUNT"/>
        <!-- LKP1 return → EXP -->
        <CONNECTOR FROMINSTANCE="LKP_FX_RATE"    FROMFIELD="RATE_TO_USD" TOINSTANCE="EXP_CALC"  TOFIELD="IN_RATE"/>
        <!-- LKP2 return → EXP -->
        <CONNECTOR FROMINSTANCE="LKP_RISK_WEIGHT" FROMFIELD="RISK_PCT"   TOINSTANCE="EXP_CALC"  TOFIELD="IN_RISK_PCT"/>
        <!-- EXP → TGT -->
        <CONNECTOR FROMINSTANCE="EXP_CALC"    FROMFIELD="OUT_BOOK_ID"  TOINSTANCE="TGT_BOOK_FACT" TOFIELD="BOOK_ID"/>
        <CONNECTOR FROMINSTANCE="EXP_CALC"    FROMFIELD="OUT_AMT_USD"  TOINSTANCE="TGT_BOOK_FACT" TOFIELD="AMT_USD"/>
        <CONNECTOR FROMINSTANCE="EXP_CALC"    FROMFIELD="OUT_RISK_AMT" TOINSTANCE="TGT_BOOK_FACT" TOFIELD="RISK_AMT"/>
        <CONNECTOR FROMINSTANCE="EXP_CALC"    FROMFIELD="OUT_LOAD_DT"  TOINSTANCE="TGT_BOOK_FACT" TOFIELD="LOAD_DT"/>
      </MAPPING>
    </FOLDER>
  </REPOSITORY>
</POWERMART>"""


DUPLICATE_CONNECTOR_XML = """<?xml version="1.0" encoding="UTF-8"?>
<POWERMART>
  <REPOSITORY NAME="R"><FOLDER NAME="F">
    <MAPPING NAME="m_DUPE_CONN">
      <TRANSFORMATION NAME="SQ_A" TYPE="Source Qualifier">
        <TABLEATTRIBUTE NAME="Sql Query" VALUE="SELECT COL1, COL2 FROM TABLE_A"/>
        <TRANSFORMFIELD NAME="COL1" DATATYPE="varchar" PRECISION="50" SCALE="0" PORTTYPE="OUTPUT"/>
        <TRANSFORMFIELD NAME="COL2" DATATYPE="varchar" PRECISION="50" SCALE="0" PORTTYPE="OUTPUT"/>
      </TRANSFORMATION>
      <TRANSFORMATION NAME="TGT_A" TYPE="Target Definition">
        <TRANSFORMFIELD NAME="COL1" DATATYPE="varchar" PRECISION="50" SCALE="0" PORTTYPE="INPUT"/>
      </TRANSFORMATION>
      <!-- DUPLICATE: COL1 and COL2 both connected to TGT_A.COL1 -->
      <CONNECTOR FROMINSTANCE="SQ_A" FROMFIELD="COL1" TOINSTANCE="TGT_A" TOFIELD="COL1"/>
      <CONNECTOR FROMINSTANCE="SQ_A" FROMFIELD="COL2" TOINSTANCE="TGT_A" TOFIELD="COL1"/>
    </MAPPING>
  </FOLDER></REPOSITORY>
</POWERMART>"""


@pytest.fixture
def multi_lookup_xml(tmp_path):
    p = tmp_path / "m_MULTI_LOOKUP.XML"
    p.write_text(MULTI_LOOKUP_XML)
    return str(p)


@pytest.fixture
def dupe_connector_xml(tmp_path):
    p = tmp_path / "m_DUPE_CONN.XML"
    p.write_text(DUPLICATE_CONNECTOR_XML)
    return str(p)


# ══════════════════════════════════════════════════════════════
# LOOKUP TESTS
# ══════════════════════════════════════════════════════════════

class TestLookupParsing:

    def test_multiple_lookups_all_captured(self, multi_lookup_xml):
        parser = InformaticaXMLParser(multi_lookup_xml)
        meta   = parser.parse_mapping("m_MULTI_LOOKUP")
        assert len(meta.lookup_details) == 3, (
            f"Expected 3 lookups, got {len(meta.lookup_details)}"
        )

    def test_lookup_names_correct(self, multi_lookup_xml):
        parser = InformaticaXMLParser(multi_lookup_xml)
        meta   = parser.parse_mapping("m_MULTI_LOOKUP")
        names  = [ld.name for ld in meta.lookup_details]
        assert "LKP_FX_RATE"     in names
        assert "LKP_RISK_WEIGHT" in names
        assert "LKP_UNCONNECTED" in names

    def test_lookup_schema_extracted(self, multi_lookup_xml):
        parser = InformaticaXMLParser(multi_lookup_xml)
        meta   = parser.parse_mapping("m_MULTI_LOOKUP")
        fx_lkp = next(ld for ld in meta.lookup_details if ld.name == "LKP_FX_RATE")
        assert fx_lkp.lookup_schema == "BLDM_REF"
        assert fx_lkp.lookup_table  == "T_FX_RATES"

    def test_lookup_sql_override_separate_from_condition(self, multi_lookup_xml):
        parser = InformaticaXMLParser(multi_lookup_xml)
        meta   = parser.parse_mapping("m_MULTI_LOOKUP")
        rw_lkp = next(ld for ld in meta.lookup_details if ld.name == "LKP_RISK_WEIGHT")
        # SQL override should contain SELECT
        assert "SELECT" in rw_lkp.lookup_sql_override
        assert "ACTIVE_FLG" in rw_lkp.lookup_sql_override

    def test_lookup_cached_flag(self, multi_lookup_xml):
        parser = InformaticaXMLParser(multi_lookup_xml)
        meta   = parser.parse_mapping("m_MULTI_LOOKUP")
        fx_lkp = next(ld for ld in meta.lookup_details if ld.name == "LKP_FX_RATE")
        rw_lkp = next(ld for ld in meta.lookup_details if ld.name == "LKP_RISK_WEIGHT")
        assert fx_lkp.is_cached  == True
        assert rw_lkp.is_cached  == False

    def test_lookup_multiple_match_policy(self, multi_lookup_xml):
        parser = InformaticaXMLParser(multi_lookup_xml)
        meta   = parser.parse_mapping("m_MULTI_LOOKUP")
        fx_lkp = next(ld for ld in meta.lookup_details if ld.name == "LKP_FX_RATE")
        rw_lkp = next(ld for ld in meta.lookup_details if ld.name == "LKP_RISK_WEIGHT")
        assert "first" in fx_lkp.multiple_match_policy.lower()
        assert "last"  in rw_lkp.multiple_match_policy.lower()

    def test_connected_lookup_detected(self, multi_lookup_xml):
        parser = InformaticaXMLParser(multi_lookup_xml)
        meta   = parser.parse_mapping("m_MULTI_LOOKUP")
        fx_lkp = next(ld for ld in meta.lookup_details if ld.name == "LKP_FX_RATE")
        assert fx_lkp.is_connected == True

    def test_unconnected_lookup_detected(self, multi_lookup_xml):
        parser = InformaticaXMLParser(multi_lookup_xml)
        meta   = parser.parse_mapping("m_MULTI_LOOKUP")
        un_lkp = next(ld for ld in meta.lookup_details if ld.name == "LKP_UNCONNECTED")
        assert un_lkp.is_connected == False

    def test_lookup_input_ports_captured(self, multi_lookup_xml):
        parser = InformaticaXMLParser(multi_lookup_xml)
        meta   = parser.parse_mapping("m_MULTI_LOOKUP")
        fx_lkp = next(ld for ld in meta.lookup_details if ld.name == "LKP_FX_RATE")
        assert "CCY_CD" in fx_lkp.input_ports

    def test_lookup_output_ports_captured(self, multi_lookup_xml):
        parser = InformaticaXMLParser(multi_lookup_xml)
        meta   = parser.parse_mapping("m_MULTI_LOOKUP")
        fx_lkp = next(ld for ld in meta.lookup_details if ld.name == "LKP_FX_RATE")
        assert "RATE_TO_USD" in fx_lkp.output_ports
        assert "RATE_DT"     in fx_lkp.output_ports


# ══════════════════════════════════════════════════════════════
# LOOKUP SHEET GENERATION TESTS
# ══════════════════════════════════════════════════════════════

class TestLookupSheet:

    def test_lookups_sheet_has_all_lookups(self, multi_lookup_xml):
        parser   = InformaticaXMLParser(multi_lookup_xml)
        meta     = parser.parse_mapping("m_MULTI_LOOKUP")
        analyzer = MappingAnalyzer(meta, parser)
        rows     = analyzer._build_lookups()
        assert len(rows) == 3

    def test_lookup_input_key_traced_to_source(self, multi_lookup_xml):
        """LKP_FX_RATE.CCY_CD should trace back to SQ_SRC.CCY_CD from BLDM_TMP.V_BOOK"""
        parser   = InformaticaXMLParser(multi_lookup_xml)
        meta     = parser.parse_mapping("m_MULTI_LOOKUP")
        analyzer = MappingAnalyzer(meta, parser)
        rows     = analyzer._build_lookups()
        fx_row   = next(r for r in rows if r["lookup_name"] == "LKP_FX_RATE")
        assert "CCY_CD" in fx_row["input_ports"]
        # Should trace upstream to SQ
        assert "CCY_CD" in fx_row["input_ports"]

    def test_unconnected_lookup_flagged(self, multi_lookup_xml):
        parser   = InformaticaXMLParser(multi_lookup_xml)
        meta     = parser.parse_mapping("m_MULTI_LOOKUP")
        analyzer = MappingAnalyzer(meta, parser)
        rows     = analyzer._build_lookups()
        un_row   = next(r for r in rows if r["lookup_name"] == "LKP_UNCONNECTED")
        assert "UNCONNECTED" in un_row["notes"].upper() or \
               un_row["lookup_type"] == "Unconnected"

    def test_output_ports_show_downstream(self, multi_lookup_xml):
        """RATE_TO_USD should show it flows to EXP_CALC.IN_RATE"""
        parser   = InformaticaXMLParser(multi_lookup_xml)
        meta     = parser.parse_mapping("m_MULTI_LOOKUP")
        analyzer = MappingAnalyzer(meta, parser)
        rows     = analyzer._build_lookups()
        fx_row   = next(r for r in rows if r["lookup_name"] == "LKP_FX_RATE")
        assert "EXP_CALC" in fx_row["output_ports"]
        assert "IN_RATE"  in fx_row["output_ports"]

    def test_unused_output_port_flagged(self, multi_lookup_xml):
        """RATE_DT output port is never connected downstream"""
        parser   = InformaticaXMLParser(multi_lookup_xml)
        meta     = parser.parse_mapping("m_MULTI_LOOKUP")
        analyzer = MappingAnalyzer(meta, parser)
        rows     = analyzer._build_lookups()
        fx_row   = next(r for r in rows if r["lookup_name"] == "LKP_FX_RATE")
        assert "NOT USED" in fx_row["output_ports"]

    def test_lookup_table_fully_qualified(self, multi_lookup_xml):
        parser   = InformaticaXMLParser(multi_lookup_xml)
        meta     = parser.parse_mapping("m_MULTI_LOOKUP")
        analyzer = MappingAnalyzer(meta, parser)
        rows     = analyzer._build_lookups()
        fx_row   = next(r for r in rows if r["lookup_name"] == "LKP_FX_RATE")
        assert fx_row["lookup_table"] == "BLDM_REF.T_FX_RATES"

    def test_sql_override_captured_in_sheet(self, multi_lookup_xml):
        parser   = InformaticaXMLParser(multi_lookup_xml)
        meta     = parser.parse_mapping("m_MULTI_LOOKUP")
        analyzer = MappingAnalyzer(meta, parser)
        rows     = analyzer._build_lookups()
        rw_row   = next(r for r in rows if r["lookup_name"] == "LKP_RISK_WEIGHT")
        assert "SELECT" in rw_row["lookup_sql_override"]


# ══════════════════════════════════════════════════════════════
# PORT RENAME / LINEAGE TRACING TESTS
# ══════════════════════════════════════════════════════════════

class TestLineageTracing:

    def test_straight_move_through_expression(self, multi_lookup_xml):
        """OUT_BOOK_ID = IN_BOOK_ID → should trace back to SQ BOOK_ID"""
        parser   = InformaticaXMLParser(multi_lookup_xml)
        meta     = parser.parse_mapping("m_MULTI_LOOKUP")
        analyzer = MappingAnalyzer(meta, parser)
        rows     = analyzer._build_mapping_table()
        book_id  = next(r for r in rows if r["target_column"] == "BOOK_ID")
        assert book_id["source_column"] == "BOOK_ID" or \
               "BOOK_ID" in book_id["technical_logic"]

    def test_local_variable_chain_resolved(self, multi_lookup_xml):
        """
        AMT_USD target = OUT_AMT_USD = V_AMT_USD = IN_AMOUNT * IN_RATE
        Should trace through LOCAL VAR correctly, not stop at variable
        """
        parser   = InformaticaXMLParser(multi_lookup_xml)
        meta     = parser.parse_mapping("m_MULTI_LOOKUP")
        analyzer = MappingAnalyzer(meta, parser)
        rows     = analyzer._build_mapping_table()
        amt      = next(r for r in rows if r["target_column"] == "AMT_USD")
        # Should show the expression, not be UNRESOLVED
        assert "UNRESOLVED" not in amt.get("notes", "")
        assert amt["technical_logic"] != ""

    def test_local_variable_nested_chain(self, multi_lookup_xml):
        """
        RISK_AMT = OUT_RISK_AMT = V_RISK_AMT = V_AMT_USD * IN_RISK_PCT / 100
        V_AMT_USD itself references IN_AMOUNT and IN_RATE — nested local var
        """
        parser   = InformaticaXMLParser(multi_lookup_xml)
        meta     = parser.parse_mapping("m_MULTI_LOOKUP")
        analyzer = MappingAnalyzer(meta, parser)
        rows     = analyzer._build_mapping_table()
        risk     = next(r for r in rows if r["target_column"] == "RISK_AMT")
        assert "UNRESOLVED" not in risk.get("notes", "")

    def test_sysdate_constant_marked(self, multi_lookup_xml):
        """OUT_LOAD_DT = SYSDATE → should be marked as CONST"""
        parser   = InformaticaXMLParser(multi_lookup_xml)
        meta     = parser.parse_mapping("m_MULTI_LOOKUP")
        analyzer = MappingAnalyzer(meta, parser)
        rows     = analyzer._build_mapping_table()
        dt_row   = next(r for r in rows if r["target_column"] == "LOAD_DT")
        assert "CONST" in dt_row.get("source_column", "") or \
               "SYSDATE" in dt_row.get("technical_logic", "")

    def test_lineage_chain_tracks_port_renames(self, multi_lookup_xml):
        """lineage_chain should show the full hop path including renamed ports"""
        parser   = InformaticaXMLParser(multi_lookup_xml)
        meta     = parser.parse_mapping("m_MULTI_LOOKUP")
        analyzer = MappingAnalyzer(meta, parser)
        rows     = analyzer._build_field_lineage()
        book_id  = next(r for r in rows if r["target_column"] == "BOOK_ID")
        chain    = book_id.get("lineage_notes", "") + book_id.get("expression_transformations","")
        # Chain should mention EXP_CALC somewhere (port was renamed)
        assert "EXP_CALC" in chain or "BOOK_ID" in chain

    def test_lookup_return_value_lineage(self, multi_lookup_xml):
        """AMT_USD lineage should mention LKP_FX_RATE as part of the chain"""
        parser   = InformaticaXMLParser(multi_lookup_xml)
        meta     = parser.parse_mapping("m_MULTI_LOOKUP")
        analyzer = MappingAnalyzer(meta, parser)
        rows     = analyzer._build_field_lineage()
        amt      = next(r for r in rows if r["target_column"] == "AMT_USD")
        # The expression references IN_RATE which comes from LKP_FX_RATE
        combined = (amt.get("expression_transformations","") +
                    amt.get("lookup_transformations","") +
                    amt.get("lineage_notes",""))
        assert combined != ""


# ══════════════════════════════════════════════════════════════
# CONNECTOR ISSUES TESTS
# ══════════════════════════════════════════════════════════════

class TestConnectorIssues:

    def test_duplicate_connector_detected(self, dupe_connector_xml):
        """Two connectors feeding same target port should be detected"""
        parser = InformaticaXMLParser(dupe_connector_xml)
        meta   = parser.parse_mapping("m_DUPE_CONN")
        dupes  = getattr(meta, '_duplicate_connectors', {})
        assert len(dupes) > 0, "Duplicate connector should have been detected"

    def test_duplicate_connector_warning_in_analysis(self, dupe_connector_xml):
        """Duplicate connector should surface as a warning in analysis"""
        parser   = InformaticaXMLParser(dupe_connector_xml)
        meta     = parser.parse_mapping("m_DUPE_CONN")
        analyzer = MappingAnalyzer(meta, parser)
        analysis = analyzer.analyze()
        warnings = analysis["warnings"]
        assert any("DUPLICATE" in w.upper() or "duplicate" in w.lower()
                   for w in warnings), f"No duplicate warning found. Warnings: {warnings}"

    def test_ports_referenced_in_expr(self, multi_lookup_xml):
        """_ports_referenced_in_expr should find IN_AMOUNT and IN_RATE in V_AMT_USD expression"""
        parser   = InformaticaXMLParser(multi_lookup_xml)
        meta     = parser.parse_mapping("m_MULTI_LOOKUP")
        analyzer = MappingAnalyzer(meta, parser)
        exp_trans = next(t for t in meta.transformations if t.name == "EXP_CALC")
        refs = analyzer._ports_referenced_in_expr("IN_AMOUNT * IN_RATE", exp_trans)
        assert "IN_AMOUNT" in refs
        assert "IN_RATE"   in refs

    def test_ports_referenced_longest_match_first(self, multi_lookup_xml):
        """COL_NM should not be shadowed by COL — longest match wins"""
        parser   = InformaticaXMLParser(multi_lookup_xml)
        meta     = parser.parse_mapping("m_MULTI_LOOKUP")
        analyzer = MappingAnalyzer(meta, parser)
        exp_trans = next(t for t in meta.transformations if t.name == "EXP_CALC")
        # Artificially test the method
        refs = analyzer._ports_referenced_in_expr("IN_BOOK_ID + IN_AMOUNT", exp_trans)
        assert "IN_BOOK_ID" in refs
        # Should not double-match IN_BOOK_ID as just IN_
        assert refs.count("IN_BOOK_ID") == 1


# ══════════════════════════════════════════════════════════════
# SQL TABLE RESOLUTION TESTS
# ══════════════════════════════════════════════════════════════

class TestSQLTableResolution:

    def test_alias_resolved_to_real_table(self, multi_lookup_xml):
        """SELECT A.BOOK_ID FROM BLDM_TMP.V_BOOK A → BOOK_ID resolves to BLDM_TMP.V_BOOK"""
        parser   = InformaticaXMLParser(multi_lookup_xml)
        meta     = parser.parse_mapping("m_MULTI_LOOKUP")
        analyzer = MappingAnalyzer(meta, parser)
        sq_trans = next(t for t in meta.transformations if t.name == "SQ_SRC")
        result   = analyzer._resolve_sq_table(sq_trans, "BOOK_ID")
        assert result in ("BLDM_TMP.V_BOOK", "V_BOOK", "A"), (
            f"Expected table resolution, got '{result}'"
        )

    def test_sql_keyword_not_returned_as_table(self, multi_lookup_xml):
        """SELECT keyword should never be returned as a table name"""
        parser   = InformaticaXMLParser(multi_lookup_xml)
        meta     = parser.parse_mapping("m_MULTI_LOOKUP")
        analyzer = MappingAnalyzer(meta, parser)
        sq_trans = next(t for t in meta.transformations if t.name == "SQ_SRC")
        for col in ["BOOK_ID", "CCY_CD", "AMOUNT"]:
            result = analyzer._resolve_sq_table(sq_trans, col)
            assert result.upper() not in (
                "SELECT", "FROM", "WHERE", "AND", "OR", "AS"
            ), f"SQL keyword returned as table for column {col}: '{result}'"


# ══════════════════════════════════════════════════════════════
# EXCEL OUTPUT TESTS
# ══════════════════════════════════════════════════════════════

class TestLookupExcelOutput:

    def test_lookups_sheet_created_in_xlsx(self, multi_lookup_xml, tmp_path):
        import openpyxl
        from bldmsttmgen.generator import generate
        out = generate(
            xml_path     = multi_lookup_xml,
            mapping_name = "m_MULTI_LOOKUP",
            out_dir      = str(tmp_path / "out")
        )
        wb = openpyxl.load_workbook(out)
        assert "Lookups" in wb.sheetnames

    def test_lookups_sheet_has_correct_row_count(self, multi_lookup_xml, tmp_path):
        import openpyxl
        from bldmsttmgen.generator import generate
        out = generate(
            xml_path     = multi_lookup_xml,
            mapping_name = "m_MULTI_LOOKUP",
            out_dir      = str(tmp_path / "out")
        )
        wb = openpyxl.load_workbook(out)
        ws = wb["Lookups"]
        assert ws.max_row - 1 == 3   # 3 lookups → 3 data rows

    def test_all_expected_sheets_present(self, multi_lookup_xml, tmp_path):
        import openpyxl
        from bldmsttmgen.generator import generate
        out = generate(
            xml_path     = multi_lookup_xml,
            mapping_name = "m_MULTI_LOOKUP",
            out_dir      = str(tmp_path / "out")
        )
        wb = openpyxl.load_workbook(out)
        # These sheets always appear regardless of mapping content
        always_present = [
            "Mapping Overview", "STTM Mapping Table", "SQL Query",
            "Rules", "Field Lineage", "Lookups",
        ]
        for sheet in always_present:
            assert sheet in wb.sheetnames, f"Missing sheet: {sheet}"
