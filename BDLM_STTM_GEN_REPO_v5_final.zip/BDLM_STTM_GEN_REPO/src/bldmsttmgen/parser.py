"""
Informatica PowerCenter XML Parser
Parses mapping XML exports and extracts all transformation metadata.
"""

import xml.etree.ElementTree as ET
import html
import os
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple


@dataclass
class Port:
    name: str
    datatype: str
    precision: str
    scale: str
    porttype: str  # INPUT, OUTPUT, LOCAL VARIABLE
    expression: str = ""
    description: str = ""


@dataclass
class LookupDetail:
    """Full detail of a single Lookup transformation."""
    name: str
    lookup_table: str
    lookup_schema: str                 # schema part if schema.table
    lookup_sql_override: str           # full SQL override if present
    default_lookup_condition: str      # the join condition (port = lookup_col)
    condition_type: str                # Equal / Less Than / etc.
    is_connected: bool                 # connected (return value used) vs unconnected
    is_cached: bool
    multiple_match_policy: str         # Use first / Use last / Error / Any
    # Port detail
    input_ports: List[str] = field(default_factory=list)    # ports feeding lookup key
    output_ports: List[str] = field(default_factory=list)   # ports returned from lookup
    return_port_map: Dict[str, str] = field(default_factory=dict)  # output_port → lookup_table_column


@dataclass
class RouterGroup:
    name: str
    condition: str


@dataclass
class Transformation:
    name: str
    type: str
    ports: List[Port] = field(default_factory=list)
    sql_query: str = ""
    # Lookup fields — comprehensive
    lookup_table: str = ""
    lookup_schema: str = ""
    lookup_sql_override: str = ""      # full SQL override if set
    lookup_condition: str = ""         # join condition (port = lkp_col)
    lookup_condition_type: str = ""    # Equal / Less Than / etc.
    lookup_is_connected: bool = True   # connected (return used) vs unconnected
    lookup_is_cached: bool = False
    lookup_multiple_match: str = ""    # Use first / Use last / Error / Any
    # Other transformations
    join_condition: str = ""
    join_type: str = ""
    filter_condition: str = ""
    update_strategy_expr: str = ""
    aggregate_filter: str = ""
    group_by_ports: List[str] = field(default_factory=list)
    router_groups: List[RouterGroup] = field(default_factory=list)
    source_table: str = ""
    source_schema: str = ""
    source_db: str = ""
    union_sources: List[str] = field(default_factory=list)


@dataclass
class Connector:
    from_transformation: str
    from_field: str
    to_transformation: str
    to_field: str


@dataclass
class MappingMetadata:
    name: str
    folder: str
    description: str = ""
    transformations: List[Transformation] = field(default_factory=list)
    connectors: List[Connector] = field(default_factory=list)
    mapplets: List[str] = field(default_factory=list)
    parameters: Dict[str, str] = field(default_factory=dict)
    mapping_variables: Dict[str, str] = field(default_factory=dict)
    has_multiple_targets: bool = False
    target_load_order: List[str] = field(default_factory=list)
    lookup_details: List[LookupDetail] = field(default_factory=list)


class InformaticaXMLParser:
    """
    Parses Informatica PowerCenter XML export files.
    Handles mapplets (embedded + standalone), special characters,
    port naming conventions, variable ports, and shared folder shortcuts.
    """

    def __init__(self, xml_path: str, mapplet_dir: Optional[str] = None,
                 mapplet_xmls: Optional[List[str]] = None):
        self.xml_path = xml_path
        self.mapplet_dir = mapplet_dir
        self.mapplet_xmls = mapplet_xmls or []
        self.tree = None
        self.root = None
        self.mapplet_registry: Dict[str, ET.Element] = {}
        self._load()

    def _load(self):
        """Load and validate XML file."""
        if not os.path.exists(self.xml_path):
            raise FileNotFoundError(f"XML file not found: {self.xml_path}")

        self.tree = ET.parse(self.xml_path)
        self.root = self.tree.getroot()

        # Validate it's an Informatica export
        if self.root.tag != "POWERMART":
            raise ValueError(
                f"Not a valid Informatica PowerCenter export. "
                f"Expected root tag <POWERMART>, got <{self.root.tag}>"
            )

        # Load mapplet registry
        self._load_mapplets()

    def _load_mapplets(self):
        """Register all available mapplet definitions."""
        # 1. Embedded mapplets in current XML
        for mapplet in self.root.iter("MAPPLET"):
            name = mapplet.get("NAME", "")
            if name:
                self.mapplet_registry[name] = mapplet

        # 2. Standalone mapplet XMLs passed explicitly
        for mx in self.mapplet_xmls:
            if os.path.exists(mx):
                self._register_mapplet_from_file(mx)

        # 3. All XMLs in mapplet directory
        if self.mapplet_dir and os.path.isdir(self.mapplet_dir):
            for fname in os.listdir(self.mapplet_dir):
                if fname.upper().endswith(".XML"):
                    self._register_mapplet_from_file(
                        os.path.join(self.mapplet_dir, fname)
                    )

    def _register_mapplet_from_file(self, path: str):
        """Parse a mapplet XML file and register its mapplets."""
        try:
            tree = ET.parse(path)
            root = tree.getroot()
            for mapplet in root.iter("MAPPLET"):
                name = mapplet.get("NAME", "")
                if name and name not in self.mapplet_registry:
                    self.mapplet_registry[name] = mapplet
        except ET.ParseError as e:
            print(f"[WARN] Could not parse mapplet file {path}: {e}")

    def list_mappings(self) -> List[str]:
        """Return all mapping names in the XML."""
        return [
            m.get("NAME", "")
            for m in self.root.iter("MAPPING")
            if m.get("NAME")
        ]

    def parse_mapping(self, mapping_name: str) -> MappingMetadata:
        """Parse a specific mapping and return full metadata."""
        mapping_el = None
        for m in self.root.iter("MAPPING"):
            if m.get("NAME") == mapping_name:
                mapping_el = m
                break

        if mapping_el is None:
            available = self.list_mappings()
            raise ValueError(
                f"Mapping '{mapping_name}' not found. "
                f"Available: {available}"
            )

        folder = self._find_folder(mapping_name)
        metadata = MappingMetadata(
            name=mapping_name,
            folder=folder,
            description=mapping_el.get("DESCRIPTION", "")
        )

        # Parse transformations
        for trans_el in mapping_el.findall("TRANSFORMATION"):
            t = self._parse_transformation(trans_el)
            metadata.transformations.append(t)

        # Parse connectors
        for conn_el in mapping_el.findall("CONNECTOR"):
            c = Connector(
                from_transformation=conn_el.get("FROMINSTANCE", ""),
                from_field=conn_el.get("FROMFIELD", ""),
                to_transformation=conn_el.get("TOINSTANCE", ""),
                to_field=conn_el.get("TOFIELD", "")
            )
            metadata.connectors.append(c)

        # Parse mapplet references
        for inst_el in mapping_el.findall("INSTANCE"):
            if inst_el.get("TYPE") == "MAPPLET":
                mplt_name = inst_el.get("TRANSFORMATION_NAME", "")
                metadata.mapplets.append(mplt_name)

        # Parse parameters and mapping variables
        metadata.parameters = self._extract_parameters(mapping_el)

        # Detect multiple targets
        targets = [t for t in metadata.transformations if "Target" in t.type]
        metadata.has_multiple_targets = len(targets) > 1
        metadata.target_load_order = [t.name for t in targets]

        # Build connected output set — any port that appears as a FROM in connectors
        connected_outputs = {(c.from_transformation, c.from_field)
                             for c in metadata.connectors}

        # Build full LookupDetail for every lookup transformation
        for t in metadata.transformations:
            if "Lookup" in t.type:
                input_ports  = [p.name for p in t.ports if p.porttype == "INPUT"]
                output_ports = [p.name for p in t.ports if p.porttype == "OUTPUT"]
                # Connected = at least one OUTPUT port is used downstream
                t.lookup_is_connected = any(
                    (t.name, p) in connected_outputs for p in output_ports
                )
                # Detect duplicate target-port connections (warn later)
                ld = LookupDetail(
                    name               = t.name,
                    lookup_table       = t.lookup_table,
                    lookup_schema      = t.lookup_schema,
                    lookup_sql_override= t.lookup_sql_override,
                    default_lookup_condition = t.lookup_condition,
                    condition_type     = t.lookup_condition_type,
                    is_connected       = t.lookup_is_connected,
                    is_cached          = t.lookup_is_cached,
                    multiple_match_policy = t.lookup_multiple_match,
                    input_ports        = input_ports,
                    output_ports       = output_ports,
                )
                metadata.lookup_details.append(ld)

        # Warn on duplicate connectors to same target port (last-write-wins bug)
        target_port_counts: Dict[tuple, int] = {}
        for c in metadata.connectors:
            key = (c.to_transformation, c.to_field)
            target_port_counts[key] = target_port_counts.get(key, 0) + 1
        metadata._duplicate_connectors = {
            k: v for k, v in target_port_counts.items() if v > 1
        }

        return metadata

    def _parse_transformation(self, trans_el: ET.Element) -> Transformation:
        """Parse a single transformation element — all types."""
        t = Transformation(
            name=trans_el.get("NAME", ""),
            type=trans_el.get("TYPE", "")
        )

        # Parse ports
        for port_el in trans_el.findall(".//TRANSFORMFIELD"):
            expr_raw = port_el.get("EXPRESSION", "")
            p = Port(
                name=port_el.get("NAME", ""),
                datatype=port_el.get("DATATYPE", ""),
                precision=port_el.get("PRECISION", ""),
                scale=port_el.get("SCALE", ""),
                porttype=port_el.get("PORTTYPE", ""),
                expression=self._decode_expression(expr_raw),
                description=port_el.get("DESCRIPTION", "")
            )
            # Aggregator: mark group-by ports
            if port_el.get("GROUP") == "YES" or port_el.get("GROUPBY") == "YES":
                t.group_by_ports.append(p.name)
            t.ports.append(p)

        attrs = {
            a.get("NAME", ""): a.get("VALUE", "")
            for a in trans_el.findall(".//TABLEATTRIBUTE")
        }

        # ── Source Qualifier ──────────────────────────────────
        if t.type == "Source Qualifier":
            t.sql_query = self._decode_expression(attrs.get("Sql Query", ""))
            t.join_condition = self._decode_expression(attrs.get("Join Condition", ""))

        # ── Lookup ────────────────────────────────────────────
        elif "Lookup" in t.type:
            raw_table = attrs.get("Lookup table name", "")
            t.lookup_table  = raw_table.split(".")[-1] if "." in raw_table else raw_table
            t.lookup_schema = raw_table.split(".")[0]  if "." in raw_table else ""
            t.lookup_sql_override = self._decode_expression(
                attrs.get("Lookup Sql Override", "")
            )
            t.lookup_condition = self._decode_expression(
                attrs.get("Lookup Condition", "")  # the port=column join condition
            )
            t.lookup_condition_type  = attrs.get("Lookup Condition Type", "=")
            t.lookup_is_cached       = attrs.get("Lookup Caching Enabled", "YES") == "YES"
            t.lookup_multiple_match  = attrs.get("Lookup Policy on Multiple Match",
                                                  "Use first value")
            # Connected: any OUTPUT port has a downstream connector (resolved later)
            t.lookup_is_connected    = True  # refined in parse_mapping post-pass

        # ── Filter ───────────────────────────────────────────
        elif t.type == "Filter":
            t.filter_condition = self._decode_expression(
                attrs.get("Filter Condition", "")
            )

        # ── Router ───────────────────────────────────────────
        elif t.type == "Router":
            for grp_el in trans_el.findall(".//GROUP"):
                grp_name = grp_el.get("NAME", "")
                grp_filter = self._decode_expression(grp_el.get("FILTER_CONDITION", ""))
                # DEFAULT group has no condition
                if grp_name.upper() == "DEFAULT":
                    grp_filter = "DEFAULT (all unmatched rows)"
                t.router_groups.append(RouterGroup(name=grp_name, condition=grp_filter))

        # ── Update Strategy ──────────────────────────────────
        elif t.type == "Update Strategy":
            t.update_strategy_expr = self._decode_expression(
                attrs.get("Update Strategy Expression", "")
            )

        # ── Aggregator ───────────────────────────────────────
        elif t.type == "Aggregator":
            t.aggregate_filter = self._decode_expression(
                attrs.get("Filter Condition", "")
            )
            # Group-by from TABLEATTRIBUTE as well
            gb = attrs.get("Group By Columns", "")
            if gb:
                for col in gb.split(","):
                    col = col.strip()
                    if col and col not in t.group_by_ports:
                        t.group_by_ports.append(col)

        # ── Joiner ───────────────────────────────────────────
        elif t.type == "Joiner":
            t.join_condition = self._decode_expression(
                attrs.get("Join Condition", "")
            )
            t.join_type = attrs.get("Join Type", "Normal")  # Normal=INNER, Master=OUTER

        # ── Source Definition (table metadata) ───────────────
        elif t.type in ("Source Definition", "Source"):
            t.source_table = attrs.get("Table Name", t.name)
            t.source_schema = attrs.get("Owner Name", "")
            t.source_db = attrs.get("Database Name", attrs.get("DBDNAME", ""))

        # ── Union ─────────────────────────────────────────────
        elif t.type == "Union":
            # Track which input groups feed this union
            for grp_el in trans_el.findall(".//GROUP"):
                grp_type = grp_el.get("TYPE", "")
                if grp_type == "INPUT":
                    t.union_sources.append(grp_el.get("NAME", ""))

        return t

    def _decode_expression(self, raw: str) -> str:
        """XML-decode expression text preserving all special characters."""
        if not raw:
            return ""
        # Decode HTML/XML entities
        decoded = html.unescape(raw)
        # Normalize line breaks (&#xD; → \n)
        decoded = decoded.replace("\r\n", "\n").replace("\r", "\n")
        return decoded

    def _find_folder(self, mapping_name: str) -> str:
        """Find the folder containing a mapping."""
        for folder_el in self.root.iter("FOLDER"):
            for m in folder_el.findall("MAPPING"):
                if m.get("NAME") == mapping_name:
                    return folder_el.get("NAME", "")
        return "Unknown"

    def _extract_parameters(self, mapping_el: ET.Element) -> Dict[str, str]:
        """Extract session parameters ($$PARAM) and mapping variables ($VAR)."""
        params = {}
        import re
        session_pat = re.compile(r'\$\$(\w+)')   # $$SESSION_PARAM
        mapping_pat = re.compile(r'(?<!\$)\$(\w+)')  # $MAPPING_VAR (single $)

        for trans_el in mapping_el.findall(".//TRANSFORMATION"):
            for attr_el in trans_el.findall(".//TABLEATTRIBUTE"):
                val = attr_el.get("VALUE", "")
                for m in session_pat.finditer(val):
                    key = f"$${m.group(1)}"
                    if key not in params:
                        params[key] = "Session parameter"
            for port_el in trans_el.findall(".//TRANSFORMFIELD"):
                expr = port_el.get("EXPRESSION", "")
                for m in session_pat.finditer(expr):
                    key = f"$${m.group(1)}"
                    if key not in params:
                        params[key] = "Session parameter"
                for m in mapping_pat.finditer(expr):
                    key = f"${m.group(1)}"
                    if key not in params:
                        params[key] = "Mapping variable"

        return params

    def resolve_mapplet_lineage(self, mapplet_name: str) -> Optional[ET.Element]:
        """Resolve a mapplet's internal definition."""
        if mapplet_name in self.mapplet_registry:
            return self.mapplet_registry[mapplet_name]
        return None

    def get_source_qualifier_sql(self, mapping_name: str) -> List[Dict]:
        """Extract all Source Qualifier SQL queries from a mapping."""
        metadata = self.parse_mapping(mapping_name)
        results = []
        rule_counter = 1

        for t in metadata.transformations:
            if t.type == "Source Qualifier":
                results.append({
                    "rule_id": f"R{rule_counter:03d}",
                    "transformation_name": t.name,
                    "type": t.type,
                    "query": t.sql_query or "[No override SQL - using default SELECT]",
                    "join_condition": t.join_condition
                })
                rule_counter += 1

        return results
